import { useState, useEffect } from 'react'

const HERO_IMAGES = [
  'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1800&q=80',
  'https://images.unsplash.com/photo-1505118380757-91f5f5632de0?w=1800&q=80',
  'https://images.unsplash.com/photo-1519451241324-20b4ea2c4220?w=1800&q=80',
  'https://images.unsplash.com/photo-1473116763249-2faaef81ccda?w=1800&q=80',
  'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=1800&q=80',
]

function fmtTime(iso) {
  if (!iso) return '--:--'
  return new Date(iso).toLocaleTimeString('en-US', { timeZone: 'America/Los_Angeles', hour: 'numeric', minute: '2-digit', hour12: true })
}

function getStatusLine(data, isNight) {
  if (!data) return { headline: 'Reading the Water...', sub: 'Fetching live conditions' }
  const { wvhtFt, dpdS, windMph } = data
  if (isNight) return { headline: 'The Shore is Yours Tonight', sub: 'Lit courts open · Stars over the Pacific' }
  if (!wvhtFt) {
    if (windMph <= 8) return { headline: 'Perfect for the Sand', sub: `${windMph.toFixed(0)}mph breeze · Ideal volleyball conditions` }
    return { headline: 'The Beach is Calling', sub: 'Live conditions loading...' }
  }
  if (wvhtFt >= 4 && dpdS >= 12) return { headline: 'The Water is On Fire', sub: `${wvhtFt.toFixed(1)}ft · ${Math.round(dpdS)}s period · Go now` }
  if (wvhtFt >= 2 && dpdS >= 10) return { headline: 'The Water is Calling', sub: `${wvhtFt.toFixed(1)}ft faces · ${Math.round(dpdS)}s period · Worth it` }
  if (windMph <= 8) return { headline: 'Perfect for the Sand', sub: `Light ${windMph.toFixed(0)}mph winds · Set the ball, work the angles` }
  return { headline: 'A Day at the Beach', sub: `${wvhtFt.toFixed(1)}ft · ${windMph.toFixed(0)}mph wind · Pick your session` }
}

function buoyAgeLabel(fetchedAt) {
  if (!fetchedAt) return null
  const mins = Math.round((Date.now() - new Date(fetchedAt)) / 60000)
  if (mins < 2)   return { text: 'Buoys live', color: 'rgba(107,174,154,0.9)' }
  if (mins < 60)  return { text: `Buoys · ${mins}min ago`, color: 'rgba(255,255,255,0.7)' }
  const hrs = Math.floor(mins / 60), rem = mins % 60
  if (hrs < 3)    return { text: `Buoys · ${hrs}h ${rem}m ago`, color: 'rgba(255,179,71,0.9)' }
  return               { text: `Buoys · ${hrs}h old`, color: 'rgba(196,97,74,0.9)' }
}

export default function HeroHeader({ data, sunriseISO, sunsetISO }) {
  const [now, setNow]   = useState(new Date())
  const [imgIdx]        = useState(() => Math.floor(Math.random() * HERO_IMAGES.length))
  useEffect(() => { const t = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(t) }, [])

  const timeStr = now.toLocaleTimeString('en-US', { timeZone: 'America/Los_Angeles', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false })
  const dateStr = now.toLocaleDateString('en-US', { timeZone: 'America/Los_Angeles', weekday: 'long', month: 'long', day: 'numeric' })

  let pct = 50, isNight = false
  if (sunriseISO && sunsetISO) {
    const sr = new Date(sunriseISO), ss = new Date(sunsetISO)
    pct = Math.max(0, Math.min(100, ((now - sr) / (ss - sr)) * 100))
    isNight = now > ss || now < sr
  }
  const remain = sunsetISO ? Math.max(0, new Date(sunsetISO) - now) : 0
  const remHrs  = Math.floor(remain / 3600000)
  const remMins = Math.floor((remain % 3600000) / 60000)

  const status = getStatusLine(data, isNight)
  const buoy = buoyAgeLabel(data?.buoyFetchedAt)

  return (
    <div style={{ position: 'relative', width: '100%', height: '420px', overflow: 'hidden', borderRadius: '0 0 32px 32px', marginBottom: '32px' }}>
      {/* Background image */}
      <img
        src={HERO_IMAGES[imgIdx]}
        alt="South Bay beach"
        style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'center 60%' }}
      />
      {/* Dark gradient overlay */}
      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to bottom, rgba(15,10,5,0.25) 0%, rgba(15,10,5,0.55) 60%, rgba(15,10,5,0.8) 100%)' }} />

      {/* Top bar — brand + buoy status */}
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, padding: '20px 36px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: '20px', fontWeight: 700, color: 'white', letterSpacing: '-0.01em' }}>South Bay Hub</div>
          <div style={{ fontFamily: 'var(--font-body)', fontSize: '11px', color: 'rgba(255,255,255,0.65)', marginTop: '2px', letterSpacing: '0.06em', textTransform: 'uppercase' }}>Hermosa · Manhattan · Redondo</div>
        </div>
        {buoy && (
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', color: buoy.color, background: 'rgba(0,0,0,0.3)', padding: '5px 12px', borderRadius: '20px', backdropFilter: 'blur(8px)', border: '1px solid rgba(255,255,255,0.1)' }}>
            ● {buoy.text}
          </div>
        )}
      </div>

      {/* Center glass card */}
      <div style={{
        position: 'absolute',
        bottom: '28px', left: '50%', transform: 'translateX(-50%)',
        width: '700px', maxWidth: 'calc(100% - 48px)',
        background: 'rgba(15,10,5,0.35)',
        backdropFilter: 'blur(20px)',
        WebkitBackdropFilter: 'blur(20px)',
        border: '1px solid rgba(255,255,255,0.12)',
        borderRadius: '20px',
        padding: '28px 36px',
        display: 'grid',
        gridTemplateColumns: '1fr auto',
        gap: '24px',
        alignItems: 'center',
      }}>
        <div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: '38px', fontWeight: 700, color: 'white', lineHeight: 1.1, letterSpacing: '-0.02em', marginBottom: '6px' }}>
            {status.headline}
          </div>
          <div style={{ fontFamily: 'var(--font-body)', fontSize: '14px', color: 'rgba(255,255,255,0.75)', fontWeight: 300, letterSpacing: '0.02em' }}>
            {status.sub}
          </div>
          {/* Sun bar */}
          <div style={{ marginTop: '18px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'var(--font-mono)', fontSize: '11px', color: 'rgba(255,255,255,0.5)', marginBottom: '6px' }}>
              <span>🌅 {fmtTime(sunriseISO)}</span>
              <span>{!isNight && remain > 0 ? `${remHrs}h ${remMins}m left` : isNight ? '🌙 Night session' : ''}</span>
              <span>🌇 {fmtTime(sunsetISO)}</span>
            </div>
            <div style={{ height: '4px', background: 'rgba(255,255,255,0.15)', borderRadius: '2px', position: 'relative' }}>
              <div style={{ height: '100%', width: `${pct}%`, background: 'linear-gradient(90deg, #FFB347, #FF7043)', borderRadius: '2px', position: 'relative', transition: 'width 1s linear' }}>
                <div style={{ position: 'absolute', right: '-4px', top: '50%', transform: 'translateY(-50%)', width: '8px', height: '8px', background: '#FFB347', borderRadius: '50%', boxShadow: '0 0 8px #FFB347' }} />
              </div>
            </div>
          </div>
        </div>

        {/* Clock */}
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '44px', fontWeight: 300, color: 'white', lineHeight: 1, letterSpacing: '0.02em', textShadow: '0 2px 20px rgba(0,0,0,0.4)' }}>
            {timeStr}
          </div>
          <div style={{ fontFamily: 'var(--font-body)', fontSize: '11px', color: 'rgba(255,255,255,0.5)', marginTop: '6px', textTransform: 'uppercase', letterSpacing: '0.08em' }}>
            {dateStr}
          </div>
        </div>
      </div>
    </div>
  )
}
