import ScoreGauge from './ScoreGauge'
import { degToCompass } from './logic'

const WIND_DIRS = { N:'↓', NE:'↙', E:'←', SE:'↖', S:'↑', SW:'↗', W:'→', NW:'↘', NNE:'↙', ENE:'↙', ESE:'↖', SSE:'↖', SSW:'↗', WSW:'↗', WNW:'↘', NNW:'↘' }

function StatBlock({ label, value, unit, large }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
      <div style={{ fontFamily: 'var(--font-body)', fontSize: '10px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.1em', fontWeight: 500 }}>{label}</div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: '3px' }}>
        <span style={{ fontFamily: 'var(--font-display)', fontSize: large ? '36px' : '22px', fontWeight: 700, color: 'var(--text-mid)', lineHeight: 1 }}>
          {value ?? '—'}
        </span>
        {unit && <span style={{ fontFamily: 'var(--font-body)', fontSize: '12px', color: 'var(--text-muted)', fontWeight: 400 }}>{unit}</span>}
      </div>
    </div>
  )
}

export default function SurfCard({ score, quality, data, advice }) {
  const color = '#2C5F78'
  const dir = data?.mwdDeg != null ? degToCompass(data.mwdDeg) : null
  const arrow = dir ? (WIND_DIRS[dir] || '→') : null

  return (
    <div style={{
      background: 'var(--card)',
      borderRadius: '20px',
      padding: '28px 28px 22px',
      boxShadow: 'var(--shadow-md)',
      border: '1px solid var(--border-soft)',
      position: 'relative',
      overflow: 'hidden',
    }}>
      {/* Accent stripe */}
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: '3px', background: `linear-gradient(90deg, ${color}, #6BAE9A)` }} />

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '20px' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span style={{ fontSize: '20px' }}>🏄</span>
            <span style={{ fontFamily: 'var(--font-display)', fontSize: '22px', fontWeight: 700, color: 'var(--text)', letterSpacing: '-0.01em' }}>Surf</span>
          </div>
          {quality && (
            <div style={{ fontFamily: 'var(--font-body)', fontSize: '12px', color: quality.color, fontWeight: 600, marginTop: '4px', textTransform: 'uppercase', letterSpacing: '0.08em' }}>
              {quality.label}
            </div>
          )}
        </div>
        <ScoreGauge score={score} color={color} size={100} />
      </div>

      {/* Big stat row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '16px', paddingBottom: '18px', borderBottom: '1px solid var(--border-soft)', marginBottom: '16px' }}>
        <StatBlock label="Height" value={data?.wvhtFt?.toFixed(1)} unit="ft" large />
        <StatBlock label="Period" value={data?.dpdS ? Math.round(data.dpdS) : null} unit="s" large />
        <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
          <div style={{ fontFamily: 'var(--font-body)', fontSize: '10px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.1em', fontWeight: 500 }}>Direction</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginTop: '2px' }}>
            {arrow && <span style={{ fontSize: '28px', color: color, lineHeight: 1 }}>{arrow}</span>}
            <span style={{ fontFamily: 'var(--font-display)', fontSize: '20px', fontWeight: 700, color: 'var(--text-mid)' }}>{dir ?? '—'}</span>
          </div>
        </div>
      </div>

      {/* Secondary stats */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '16px' }}>
        {[
          { label: 'Inner (46221)', value: data?.wvhtFt21?.toFixed(1), unit: 'ft' },
          { label: 'Outer (46025)', value: data?.wvhtFt25?.toFixed(1), unit: 'ft' },
        ].map(s => (
          <div key={s.label} style={{ background: 'var(--sand)', borderRadius: '10px', padding: '10px 12px' }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-muted)', marginBottom: '3px' }}>{s.label}</div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: '18px', fontWeight: 700, color: color }}>{s.value ?? '—'}<span style={{ fontFamily:'var(--font-body)', fontSize:'11px', color:'var(--text-muted)', marginLeft:'2px' }}>{s.unit}</span></div>
          </div>
        ))}
      </div>

      {/* Advice */}
      <div style={{ fontFamily: 'var(--font-display)', fontSize: '14px', fontStyle: 'italic', color: 'var(--text-mid)', lineHeight: 1.6, paddingTop: '12px', borderTop: '1px solid var(--border-soft)' }}>
        "{advice || 'Fetching buoy data — check back shortly.'}"
      </div>

      {/* Buoy timestamps */}
      {data?.b25Time && (
        <div style={{ display: 'flex', gap: '12px', marginTop: '12px' }}>
          {[['46025', data.b25Time, '#2C5F78'], ['46221', data.b21Time, '#6BAE9A']].map(([id, t, c]) => t && (
            <div key={id} style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', color: 'var(--text-light)', display: 'flex', alignItems: 'center', gap: '4px' }}>
              <span style={{ width: '5px', height: '5px', borderRadius: '50%', background: c, display: 'inline-block' }} />
              {id} · {t.split(' ').slice(1).join(' ')}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
