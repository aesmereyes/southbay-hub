import { useState, useEffect, useCallback, useRef } from 'react'

const BASE = import.meta.env.BASE_URL

// Open-Meteo Marine — CORS enabled, free, no API key, works from browser
// This is the PRIMARY wave data source
const MARINE_URL =
  'https://marine-api.open-meteo.com/v1/marine' +
  '?latitude=33.88&longitude=-118.41' +
  '&current=wave_height,wave_period,wave_direction,' +
  'wind_wave_height,wind_wave_period,' +
  'swell_wave_height,swell_wave_period,swell_wave_direction' +
  '&hourly=wave_height,wave_period,wave_direction,swell_wave_height,swell_wave_period' +
  '&timezone=America%2FLos_Angeles&forecast_days=3'

// Open-Meteo Weather — CORS enabled, free, no API key
const WEATHER_URL =
  'https://api.open-meteo.com/v1/forecast' +
  '?latitude=33.88&longitude=-118.41' +
  '&current=temperature_2m,wind_speed_10m,wind_direction_10m,cloud_cover,uv_index' +
  '&daily=sunrise,sunset' +
  '&timezone=America%2FLos_Angeles&forecast_days=2'

// NOAA buoy JSON — fetched hourly by GitHub Actions, served from same origin (no CORS)
const BUOY_URL = () => `${BASE}buoy-data.json?t=${Math.floor(Date.now()/300000)}`

export function useStationData() {
  const [data, setData]       = useState(null)
  const [error, setError]     = useState(null)
  const [loading, setLoading] = useState(true)
  const [lastFetch, setLastFetch] = useState(null)
  const timerRef = useRef(null)

  const fetchAll = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      // Fetch marine + weather in parallel (both have CORS, work directly from browser)
      // Buoy JSON is optional — don't let it fail everything
      const [marineRes, weatherRes, buoyRes] = await Promise.all([
        fetch(MARINE_URL),
        fetch(WEATHER_URL),
        fetch(BUOY_URL()).catch(() => null),
      ])

      if (!marineRes.ok) throw new Error(`Marine API: ${marineRes.status}`)
      if (!weatherRes.ok) throw new Error(`Weather API: ${weatherRes.status}`)

      const [marine, weather] = await Promise.all([
        marineRes.json(),
        weatherRes.json(),
      ])

      const buoy = buoyRes?.ok ? await buoyRes.json().catch(() => null) : null

      const mc = marine.current
      const wc = weather.current

      // Wave height in meters → feet
      const waveHtFt  = mc.wave_height       ? +(mc.wave_height       * 3.281).toFixed(1) : null
      const swellHtFt = mc.swell_wave_height ? +(mc.swell_wave_height * 3.281).toFixed(1) : null
      const windWaveHtFt = mc.wind_wave_height ? +(mc.wind_wave_height * 3.281).toFixed(1) : null

      // Hourly arrays for 48hr trend chart
      const hourlyTimes    = marine.hourly.time.slice(0, 48)
      const hourlyWaveHt   = marine.hourly.wave_height.slice(0, 48).map(h => h ? +(h*3.281).toFixed(1) : null)
      const hourlyPeriod   = marine.hourly.wave_period.slice(0, 48)
      const hourlySwellHt  = marine.hourly.swell_wave_height?.slice(0, 48).map(h => h ? +(h*3.281).toFixed(1) : null) ?? []
      const hourlySwellPer = marine.hourly.swell_wave_period?.slice(0, 48) ?? []

      const windMph = +((wc.wind_speed_10m * 0.6214).toFixed(1))
      const tempF   = +((wc.temperature_2m * 9/5 + 32).toFixed(1))

      setData({
        // Primary surf data (Open-Meteo Marine)
        wvhtFt:        waveHtFt,
        dpdS:          mc.wave_period     ?? null,
        mwdDeg:        mc.wave_direction  ?? null,
        swellHtFt,
        swellPeriod:   mc.swell_wave_period   ?? null,
        swellDirDeg:   mc.swell_wave_direction ?? null,
        windWaveHtFt,
        windWavePeriod: mc.wind_wave_period ?? null,

        // Hourly trend data
        hourlyTimes,
        hourlyWaveHt,
        hourlyPeriod,
        hourlySwellHt,
        hourlySwellPer,

        // Weather
        windMph,
        windDirDeg:  wc.wind_direction_10m,
        cloudPct:    wc.cloud_cover,
        uvIndex:     wc.uv_index,
        tempF,
        sunriseISO:  weather.daily.sunrise[0],
        sunsetISO:   weather.daily.sunset[0],

        // NOAA buoy detail (bonus — from GitHub Actions, may be null)
        stations:      buoy?.stations   ?? null,
        buoyFetchedAt: buoy?.fetched_at ?? null,
        waterTempF:    buoy?.stations?.['46221']?.data?.wtmp_f
                    ?? buoy?.stations?.['46025']?.data?.wtmp_f
                    ?? null,

        // For compat
        wvhtFt21: buoy?.stations?.['46221']?.data?.wvht_ft ?? null,
        wvhtFt25: buoy?.stations?.['46025']?.data?.wvht_ft ?? null,
        b21Time:  buoy?.stations?.['46221']?.data?.timestamp ?? null,
        b25Time:  buoy?.stations?.['46025']?.data?.timestamp ?? null,
      })
      setLastFetch(new Date())
    } catch (e) {
      console.error('Data fetch error:', e)
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchAll()
    timerRef.current = setInterval(fetchAll, 30 * 60 * 1000)
    return () => clearInterval(timerRef.current)
  }, [fetchAll])

  return { data, error, loading, lastFetch, refetch: fetchAll }
}
