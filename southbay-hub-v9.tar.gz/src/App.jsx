import { useState } from 'react'
import { useStationData } from './useStationData'
import { calcSurfScore, surfQuality, surfAdvice, calcVolleyScore, windCondition, windDriftAdvice } from './logic'
import HeroHeader      from './HeroHeader'
import SurfCard        from './SurfCard'
import VolleyCard      from './VolleyCard'
import ConditionsStrip from './ConditionsStrip'
import BestSpotPanel   from './BestSpotPanel'
import SurfCams        from './SurfCams'
import BuoyDashboard   from './BuoyDashboard'
import Schedule        from './Schedule'
import SpotMap, { SPOTS } from './SpotMap'
import MeetupBoard     from './MeetupBoard'

function SectionHeading({ title, sub }) {
  return (
    <div style={{ display:'flex', alignItems:'baseline', gap:'12px', marginBottom:'16px' }}>
      <h2 style={{ fontFamily:'var(--font-display)', fontSize:'26px', fontWeight:700, color:'var(--text)', letterSpacing:'-0.01em' }}>{title}</h2>
      {sub && <span style={{ fontFamily:'var(--font-body)', fontSize:'12px', color:'var(--text-muted)', fontWeight:300 }}>{sub}</span>}
    </div>
  )
}

export default function App() {
  const { data, error, loading, lastFetch, refetch } = useStationData()
  const [activeSpot, setActiveSpot] = useState(null)

  const surfScore = data ? calcSurfScore({ heightFt:data.wvhtFt, periodS:data.dpdS??data.swellPeriod, windMph:data.windMph }) : 0
  const surfQual  = data ? surfQuality(surfScore, data.wvhtFt, data.dpdS??data.swellPeriod) : null
  const surfTip   = data ? surfAdvice({ score:surfScore, heightFt:data.wvhtFt, periodS:data.dpdS??data.swellPeriod, windMph:data.windMph, mwdDeg:data.mwdDeg??data.swellDirDeg }) : null
  const volScore  = data ? calcVolleyScore({ windMph:data.windMph, cloudPct:data.cloudPct }) : 0
  const volCond   = data ? windCondition(data.windMph) : null
  const volTip    = data ? windDriftAdvice({ windMph:data.windMph, windDirDeg:data.windDirDeg }) : null

  return (
    <div style={{ background:'var(--sand)', minHeight:'100vh' }}>
      <HeroHeader data={data} sunriseISO={data?.sunriseISO} sunsetISO={data?.sunsetISO} />

      <div style={{ maxWidth:'1280px', margin:'0 auto', padding:'0 28px 60px', position:'relative', zIndex:1 }}>

        {error && (
          <div style={{ background:'rgba(196,97,74,0.08)', border:'1px solid rgba(196,97,74,0.2)', borderRadius:'12px', padding:'14px 20px', marginBottom:'24px', display:'flex', justifyContent:'space-between', alignItems:'center', fontFamily:'var(--font-body)', fontSize:'13px', color:'#C4614A' }}>
            <span>⚠️ {error}</span>
            <button onClick={refetch} style={{ padding:'7px 16px', background:'transparent', border:'1px solid #C4614A', borderRadius:'8px', color:'#C4614A', cursor:'pointer', fontFamily:'var(--font-body)', fontSize:'12px' }}>Retry</button>
          </div>
        )}

        {loading && !data && (
          <div style={{ textAlign:'center', padding:'60px 0', fontFamily:'var(--font-display)', fontSize:'22px', fontStyle:'italic', color:'var(--text-muted)' }}>
            <style>{`@keyframes bob{0%,100%{transform:translateY(0)}50%{transform:translateY(-7px)}}`}</style>
            <span style={{ display:'inline-block', animation:'bob 1.8s ease-in-out infinite', marginRight:'12px' }}>🌊</span>
            Reading the water…
          </div>
        )}

        {/* SPORT OVERVIEW CARDS */}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'18px', marginBottom:'28px' }}>
          <SurfCard   score={surfScore} quality={surfQual} data={data} advice={surfTip} />
          <VolleyCard score={volScore}  condition={volCond} data={data} advice={volTip} />
        </div>

        {/* CONDITIONS + WATER TEMP + TIDES */}
        <ConditionsStrip data={data} />

        {/* WHERE TO SURF — ranked recommendation */}
        <BestSpotPanel beaches={data?.beaches} windMph={data?.windMph} />

        {/* LIVE CAMERAS */}
        <SurfCams />

        {/* BUOY NETWORK */}
        <BuoyDashboard stations={data?.stations} fetchedAt={data?.buoyFetchedAt} />

        {/* SCHEDULE */}
        <Schedule />

        {/* MAP */}
        <SectionHeading title="Spot Locator" sub="🍦 Pink = Creamy Boys · Buoys shown offshore" />
        <div style={{ display:'grid', gridTemplateColumns:'1fr 280px', gap:'18px', marginBottom:'36px' }}>
          <SpotMap activeSpot={activeSpot} onSpotClick={setActiveSpot} />
          <div style={{ display:'flex', flexDirection:'column', gap:'7px', overflowY:'auto', maxHeight:'460px' }}>
            {[...SPOTS].sort((a,b)=>a.id==='hermosa-pier'?-1:b.id==='hermosa-pier'?1:0).map(spot=>(
              <div key={spot.id} onClick={()=>setActiveSpot(spot.id===activeSpot?null:spot.id)}
                style={{ background:spot.id===activeSpot?'var(--pacific)':spot.id==='hermosa-pier'?'#fff8f0':'var(--card)', border:`1px solid ${spot.id===activeSpot?'var(--pacific)':spot.id==='hermosa-pier'?spot.color+'40':'var(--border-soft)'}`, borderRadius:'12px', padding:'12px 14px', cursor:'pointer', boxShadow:'var(--shadow-sm)', transition:'all 0.2s' }}>
                <div style={{ fontFamily:'var(--font-display)', fontSize:'13px', fontWeight:700, color:spot.id===activeSpot?'white':'var(--text)' }}>{spot.id==='hermosa-pier'?'⭐ ':''}{spot.name}</div>
                <div style={{ fontFamily:'var(--font-mono)', fontSize:'10px', color:spot.id===activeSpot?'rgba(255,255,255,0.65)':'var(--text-muted)', margin:'3px 0 6px' }}>{spot.sub}</div>
                <span style={{ fontFamily:'var(--font-body)', fontSize:'10px', fontWeight:600, padding:'2px 8px', borderRadius:'10px', background:spot.id===activeSpot?'rgba(255,255,255,0.2)':spot.color+'18', color:spot.id===activeSpot?'white':spot.color }}>{spot.tag}</span>
              </div>
            ))}
            <div style={{ fontFamily:'var(--font-body)', fontSize:'11px', color:'#db2777', fontWeight:600, marginTop:'8px', paddingTop:'10px', borderTop:'1px solid rgba(244,114,182,0.2)' }}>🍦 Creamy Boys</div>
            {[
              { name:'Hermosa Ave', sub:'1136 Hermosa Ave · Steps from courts' },
              { name:'El Segundo',  sub:'118 W Grand Ave · Near Dockweiler' },
            ].map(cb=>(
              <div key={cb.name} style={{ background:'#fff5fb', border:'1px solid rgba(244,114,182,0.2)', borderRadius:'12px', padding:'11px 13px', boxShadow:'var(--shadow-sm)' }}>
                <div style={{ fontFamily:'var(--font-display)', fontSize:'13px', fontWeight:700, color:'#be185d' }}>🍦 {cb.name}</div>
                <div style={{ fontFamily:'var(--font-mono)', fontSize:'10px', color:'#9d174d', marginTop:'2px' }}>{cb.sub}</div>
                <div style={{ fontFamily:'var(--font-mono)', fontSize:'9px', color:'#db2777', marginTop:'3px' }}>Mon–Thu 12–10 · Fri–Sat 12–11</div>
              </div>
            ))}
          </div>
        </div>

        <MeetupBoard />

        <div style={{ borderTop:'1px solid var(--border)', paddingTop:'20px', display:'flex', justifyContent:'space-between', alignItems:'center', fontFamily:'var(--font-body)', fontSize:'11px', color:'var(--text-muted)' }}>
          <span style={{ fontFamily:'var(--font-display)', fontSize:'16px', fontStyle:'italic', color:'var(--driftwood)' }}>South Bay Hub</span>
          <span>Marine: Open-Meteo · Water temp: NOAA CO-OPS · Cameras: HDOnTap · Hermosa · Manhattan · Redondo</span>
        </div>
      </div>
    </div>
  )
}
