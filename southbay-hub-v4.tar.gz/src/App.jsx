import { useState } from 'react'
import { useStationData } from './useStationData'
import { calcSurfScore, surfQuality, surfAdvice, calcVolleyScore, windCondition, windDriftAdvice } from './logic'
import DaylightHeader  from './DaylightHeader'
import SurfCard        from './SurfCard'
import VolleyCard      from './VolleyCard'
import ConditionsStrip from './ConditionsStrip'
import SpotMap, { SPOTS } from './SpotMap'
import Schedule        from './Schedule'
import MeetupBoard     from './MeetupBoard'

function SectionTitle({ children, sub }) {
  return (
    <div style={{ display:'flex', alignItems:'center', gap:'12px', margin:'0 0 14px' }}>
      <div>
        <span style={{ fontFamily:'var(--font-display)', fontSize:'20px', fontWeight:700, color:'var(--text)' }}>{children}</span>
        {sub && <span style={{ fontFamily:'var(--font-mono)', fontSize:'10px', color:'var(--text-muted)', marginLeft:'10px', textTransform:'uppercase', letterSpacing:'0.06em' }}>{sub}</span>}
      </div>
      <div style={{ flex:1, height:'1px', background:'var(--border)' }} />
    </div>
  )
}

export default function App() {
  const { data, error, loading, lastFetch, refetch } = useStationData()
  const [activeSpot, setActiveSpot] = useState(null)

  const surfScore = data ? calcSurfScore({ heightFt: data.wvhtFt, periodS: data.dpdS, windMph: data.windMph }) : 0
  const surfQual  = data ? surfQuality(surfScore, data.wvhtFt, data.dpdS) : null
  const surfTip   = data ? surfAdvice({ score: surfScore, heightFt: data.wvhtFt, periodS: data.dpdS, windMph: data.windMph, mwdDeg: data.mwdDeg }) : null
  const volScore  = data ? calcVolleyScore({ windMph: data.windMph, cloudPct: data.cloudPct }) : 0
  const volCond   = data ? windCondition(data.windMph) : null
  const volTip    = data ? windDriftAdvice({ windMph: data.windMph, windDirDeg: data.windDirDeg }) : null

  return (
    <div style={{ position:'relative', zIndex:1, maxWidth:'1280px', margin:'0 auto', padding:'0 28px 60px' }}>

      <DaylightHeader sunriseISO={data?.sunriseISO} sunsetISO={data?.sunsetISO} lastFetch={lastFetch} buoyFetchedAt={data?.buoyFetchedAt} />

      {/* Notices */}
      {data?.buoyError && !data?.wvhtFt && (
        <div style={{ background:'rgba(212,130,74,0.1)', border:'1px solid rgba(212,130,74,0.3)', borderRadius:'10px', padding:'12px 18px', margin:'16px 0', fontFamily:'var(--font-body)', fontSize:'13px', color:'var(--sunset)', display:'flex', justifyContent:'space-between', alignItems:'center', position:'relative', zIndex:1 }}>
          <span>🌊 Buoy data pending first fetch — GitHub Actions updates it hourly. Weather scores are live.</span>
          <button onClick={refetch} style={{ background:'transparent', border:'1px solid var(--sunset)', borderRadius:'6px', color:'var(--sunset)', fontFamily:'var(--font-mono)', fontSize:'11px', padding:'6px 14px', cursor:'pointer', marginLeft:'12px', textTransform:'uppercase', letterSpacing:'0.06em' }}>Retry</button>
        </div>
      )}
      {error && (
        <div style={{ background:'rgba(196,97,74,0.1)', border:'1px solid rgba(196,97,74,0.3)', borderRadius:'10px', padding:'12px 18px', margin:'16px 0', fontFamily:'var(--font-body)', fontSize:'13px', color:'var(--coral)', position:'relative', zIndex:1 }}>
          ⚠️ {error}
        </div>
      )}
      {loading && !data && (
        <div style={{ textAlign:'center', padding:'48px 0', fontFamily:'var(--font-mono)', fontSize:'13px', color:'var(--text-muted)', position:'relative', zIndex:1 }}>
          <style>{`@keyframes bob{0%,100%{transform:translateY(0)}50%{transform:translateY(-5px)}}`}</style>
          <span style={{ display:'inline-block', animation:'bob 1.4s ease-in-out infinite', marginRight:'10px', fontSize:'22px' }}>🌊</span>
          Loading conditions...
        </div>
      )}

      {/* DUAL SCORE HERO */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'18px', margin:'24px 0 18px', position:'relative', zIndex:1 }}>
        <SurfCard   score={surfScore} quality={surfQual} data={data} advice={surfTip} />
        <VolleyCard score={volScore}  condition={volCond} data={data} advice={volTip} />
      </div>

      <ConditionsStrip data={data} />

      {/* WEEKLY SCHEDULE */}
      <Schedule />

      {/* SPOT LOCATOR */}
      <SectionTitle sub="🍦 Pink = Creamy Boys · 🟢 Buoy stations offshore">Spot Locator</SectionTitle>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 290px', gap:'18px', marginBottom:'28px', position:'relative', zIndex:1 }}>
        <SpotMap activeSpot={activeSpot} onSpotClick={setActiveSpot} />
        <div style={{ display:'flex', flexDirection:'column', gap:'7px', overflowY:'auto', maxHeight:'480px', paddingRight:'2px' }}>
          {/* Hermosa first as home */}
          {[...SPOTS].sort((a,b) => {
            if (a.id === 'hermosa-pier') return -1
            if (b.id === 'hermosa-pier') return 1
            return 0
          }).map(spot => (
            <div key={spot.id} onClick={() => setActiveSpot(spot.id === activeSpot ? null : spot.id)}
              style={{
                background: spot.id === activeSpot ? 'var(--sand-deeper)' : spot.id === 'hermosa-pier' ? '#fdf6ee' : 'var(--sand-dark)',
                border:`1px solid ${spot.id === activeSpot ? spot.color : spot.id === 'hermosa-pier' ? 'var(--driftwood)' : 'var(--border-soft)'}`,
                borderRadius:'10px', padding:'11px 13px', cursor:'pointer', transition:'all 0.2s',
              }}>
              <div style={{ fontFamily:'var(--font-display)', fontSize:'13px', fontWeight:600, color:'var(--text)' }}>
                {spot.id === 'hermosa-pier' ? '⭐ ' : ''}{spot.name}
              </div>
              <div style={{ fontFamily:'var(--font-mono)', fontSize:'10px', color:'var(--text-muted)', margin:'2px 0 5px' }}>{spot.sub}</div>
              <span style={{ display:'inline-block', fontFamily:'var(--font-mono)', fontSize:'10px', padding:'2px 7px', borderRadius:'10px', background:`${spot.color}15`, color:spot.color, letterSpacing:'0.04em' }}>{spot.tag}</span>
            </div>
          ))}

          {/* Creamy Boys separator */}
          <div style={{ fontFamily:'var(--font-mono)', fontSize:'10px', color:'#db2777', textTransform:'uppercase', letterSpacing:'0.08em', marginTop:'6px', paddingTop:'8px', borderTop:'1px solid rgba(244,114,182,0.2)' }}>
            🍦 Creamy Boys
          </div>
          {[
            { id:'cb-hermosa', name:'Hermosa Ave', sub:'1136 Hermosa Ave · 0.1mi from courts' },
            { id:'cb-elseg',   name:'El Segundo',  sub:'118 W Grand Ave · Near Dockweiler'   },
          ].map(cb => (
            <div key={cb.id} style={{ background:'#fdf2f8', border:'1px solid rgba(244,114,182,0.25)', borderRadius:'10px', padding:'10px 13px' }}>
              <div style={{ fontFamily:'var(--font-display)', fontSize:'13px', fontWeight:600, color:'#be185d' }}>🍦 {cb.name}</div>
              <div style={{ fontFamily:'var(--font-mono)', fontSize:'10px', color:'#9d174d', marginTop:'2px' }}>{cb.sub}</div>
              <div style={{ fontFamily:'var(--font-mono)', fontSize:'9px', color:'#db2777', marginTop:'3px' }}>Mon–Thu 12–10pm · Fri–Sat 12–11pm</div>
            </div>
          ))}
        </div>
      </div>

      <MeetupBoard />

      <div style={{ borderTop:'1px solid var(--border)', paddingTop:'20px', display:'flex', justifyContent:'space-between', fontFamily:'var(--font-mono)', fontSize:'10px', color:'var(--text-muted)', letterSpacing:'0.05em' }}>
        <span>SOUTH BAY HUB · Hermosa · Manhattan · Redondo</span>
        <span>NOAA 46025 + 46221 (hourly via Actions) · Open-Meteo (live)</span>
      </div>
    </div>
  )
}
