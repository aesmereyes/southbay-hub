import ScoreGauge from './ScoreGauge'
import { degToCompass } from './logic'

function Row({ label, value, unit }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 0', borderBottom: '1px solid var(--border-soft)' }}>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{label}</span>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: '13px', color: 'var(--text-mid)', fontWeight: 500 }}>
        {value ?? '—'}{unit && <span style={{ fontSize: '10px', color: 'var(--text-light)', marginLeft: '3px' }}>{unit}</span>}
      </span>
    </div>
  )
}

export default function SurfCard({ score, quality, data, advice }) {
  const color = '#2a6b8a'

  return (
    <div style={{ background: 'var(--sand-dark)', border: '1px solid var(--border)', borderRadius: '16px', padding: '24px 26px', position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: '3px', background: `linear-gradient(90deg, transparent, ${color}, transparent)` }} />

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '18px' }}>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: '18px', fontWeight: 700, color: 'var(--text)', display: 'flex', alignItems: 'center', gap: '8px' }}>
          🌊 Surf Score
        </div>
        {quality && (
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', padding: '4px 12px', borderRadius: '20px', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 500, background: quality.bg, color: quality.color, border: `1px solid ${quality.color}30` }}>
            {quality.label}
          </span>
        )}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'auto 1fr', gap: '20px', alignItems: 'start' }}>
        <ScoreGauge score={score} color={color} />
        <div style={{ paddingTop: '4px' }}>
          <Row label="Height · Inner (46221)" value={data?.wvhtFt21?.toFixed(1)} unit="ft" />
          <Row label="Height · Outer (46025)" value={data?.wvhtFt25?.toFixed(1)} unit="ft" />
          <Row label="Period"    value={data?.dpdS ? Math.round(data.dpdS) : null} unit="s" />
          <Row label="Direction" value={data?.mwdDeg != null ? `${degToCompass(data.mwdDeg)} (${Math.round(data.mwdDeg)}°)` : null} />
        </div>
      </div>

      {/* Buoy timestamps */}
      {data && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px', marginTop: '14px' }}>
          {[
            { label: '46025 Outer', time: data.b25Time, color: '#2a6b8a' },
            { label: '46221 Inner', time: data.b21Time, color: '#4a5e3a' },
          ].map(b => (
            <div key={b.label} style={{ background: 'rgba(139,115,85,0.08)', border: `1px solid ${b.color}20`, borderRadius: '6px', padding: '6px 10px' }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: b.color, fontWeight: 500 }}>{b.label}</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', color: 'var(--text-muted)', marginTop: '2px' }}>{b.time?.split(' ').slice(1).join(' ') ?? 'pending first fetch'}</div>
            </div>
          ))}
        </div>
      )}

      <div style={{ marginTop: '14px', padding: '12px 14px', background: `${color}08`, border: `1px solid ${color}15`, borderRadius: '8px', fontFamily: 'var(--font-body)', fontSize: '13px', color: 'var(--text-mid)', lineHeight: 1.6 }}>
        {advice || 'Fetching buoy data...'}
      </div>
    </div>
  )
}
