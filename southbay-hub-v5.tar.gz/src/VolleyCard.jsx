import ScoreGauge from './ScoreGauge'
import { degToCompass } from './logic'

function Row({ label, value, unit }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 0', borderBottom: '1px solid var(--border-soft)' }}>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{label}</span>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: '13px', color: 'var(--text-mid)', fontWeight: 500 }}>
        {value ?? '—'}{unit && <span style={{ fontSize: '10px', color: 'var(--text-light)', marginLeft: '3px' }}>{unit}</span>}
      </span>
    </div>
  )
}

const WIND_TABLE = [
  { max: 5,   label: '0–5 mph',   condition: 'PURE',      detail: 'Zero drift · Perfect for setting',           color: '#4a5e3a' },
  { max: 12,  label: '6–12 mph',  condition: 'BREEZY',    detail: 'Slight drift · Use wind on float serves',    color: '#2a6b8a' },
  { max: 20,  label: '13–20 mph', condition: 'HEAVY',     detail: 'Keep sets low · 3ft off the net',            color: '#d4824a' },
  { max: 999, label: '21+ mph',   condition: 'BLOWN OUT', detail: 'Sand flying · Hero serves only',             color: '#c4614a' },
]

export default function VolleyCard({ score, condition, data, advice }) {
  const color = '#4a5e3a'
  const windRow = data?.windMph != null ? WIND_TABLE.find(r => data.windMph <= r.max) : null

  return (
    <div style={{ background: 'var(--sand-dark)', border: '1px solid var(--border)', borderRadius: '16px', padding: '24px 26px', position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: '3px', background: `linear-gradient(90deg, transparent, ${color}, transparent)` }} />

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '18px' }}>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: '18px', fontWeight: 700, color: 'var(--text)', display: 'flex', alignItems: 'center', gap: '8px' }}>
          🏐 Volley Score
        </div>
        {condition && (
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', padding: '4px 12px', borderRadius: '20px', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 500, background: condition.bg, color: condition.color, border: `1px solid ${condition.color}30` }}>
            {condition.label}
          </span>
        )}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'auto 1fr', gap: '20px', alignItems: 'start' }}>
        <ScoreGauge score={score} color={color} />
        <div style={{ paddingTop: '4px' }}>
          <Row label="Wind Speed"  value={data?.windMph?.toFixed(1)} unit="mph" />
          <Row label="Direction"   value={data?.windDirDeg != null ? `${degToCompass(data.windDirDeg)} (${Math.round(data.windDirDeg)}°)` : null} />
          <Row label="UV Index"    value={data?.uvIndex?.toFixed(1)} />
          <Row label="Cloud Cover" value={data?.cloudPct != null ? Math.round(data.cloudPct) : null} unit="%" />
        </div>
      </div>

      {windRow && (
        <div style={{ marginTop: '14px', background: `${windRow.color}10`, border: `1px solid ${windRow.color}25`, borderRadius: '8px', padding: '10px 14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', color: windRow.color, fontWeight: 600, letterSpacing: '0.06em' }}>{windRow.condition}</div>
            <div style={{ fontFamily: 'var(--font-body)', fontSize: '12px', color: 'var(--text-mid)', marginTop: '2px' }}>{windRow.detail}</div>
          </div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', color: 'var(--text-muted)' }}>{windRow.label}</div>
        </div>
      )}

      <div style={{ marginTop: '12px', padding: '12px 14px', background: `${color}08`, border: `1px solid ${color}15`, borderRadius: '8px', fontFamily: 'var(--font-body)', fontSize: '13px', color: 'var(--text-mid)', lineHeight: 1.6 }}>
        {advice || 'Fetching weather data...'}
      </div>
    </div>
  )
}
