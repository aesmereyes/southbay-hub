import { useState, useEffect, useCallback, useRef } from 'react'

const BASE = import.meta.env.BASE_URL

const WEATHER_URL =
  'https://api.open-meteo.com/v1/forecast' +
  '?latitude=33.88&longitude=-118.41' +
  '&current=temperature_2m,wind_speed_10m,wind_direction_10m,cloud_cover,uv_index' +
  '&daily=sunrise,sunset' +
  '&timezone=America%2FLos_Angeles&forecast_days=2'

export function useStationData() {
  const [data, setData]       = useState(null)
  const [error, setError]     = useState(null)
  const [loading, setLoading] = useState(true)
  const [lastFetch, setLastFetch] = useState(null)
  const timerRef = useRef(null)

  const fetchAll = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const [buoyRes, weatherRes] = await Promise.all([
        fetch(`${BASE}buoy-data.json?t=${Date.now()}`),
        fetch(WEATHER_URL),
      ])
      const buoy    = await buoyRes.json()
      const weather = await weatherRes.json()

      const st = buoy.stations || {}
      // Primary scoring buoys
      const b25 = st['46025']?.data
      const b21 = st['46221']?.data

      const w = weather.current
      setData({
        // Scoring inputs (dual-buoy strategy)
        wvhtFt:    b21?.wvht_ft ?? b25?.wvht_ft ?? null,
        dpdS:      b25?.dpd_s   ?? b21?.dpd_s   ?? null,
        mwdDeg:    b25?.mwd_deg ?? b21?.mwd_deg ?? null,
        wvhtFt25:  b25?.wvht_ft ?? null,
        wvhtFt21:  b21?.wvht_ft ?? null,
        b25Time:   b25?.timestamp ?? null,
        b21Time:   b21?.timestamp ?? null,
        waterTempF: b21?.wtmp_f ?? b25?.wtmp_f ?? null,

        // All stations for the dashboard panel
        stations: st,
        buoyFetchedAt: buoy.fetched_at,
        buoyErrors:    buoy.errors ?? {},

        // Weather
        windMph:    +((w.wind_speed_10m * 0.6214).toFixed(1)),
        windDirDeg: w.wind_direction_10m,
        cloudPct:   w.cloud_cover,
        uvIndex:    w.uv_index,
        tempF:      +((w.temperature_2m * 9/5 + 32).toFixed(1)),
        sunriseISO: weather.daily.sunrise[0],
        sunsetISO:  weather.daily.sunset[0],
      })
      setLastFetch(new Date())
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchAll()
    timerRef.current = setInterval(fetchAll, 30 * 60 * 1000)
    return () => clearInterval(timerRef.current)
  }, [fetchAll])

  return { data, error, loading, lastFetch, refetch: fetchAll }
}
