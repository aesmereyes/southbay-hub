import { useEffect, useRef } from 'react'
import L from 'leaflet'

export const SPOTS = [
  // ── MANHATTAN BEACH ──
  { id: 'marine',       name: 'Marine St Courts',        sub: 'Manhattan Beach',    tag: 'Pro Focus',      lat: 33.8853, lon: -118.4104, color: '#2a6b8a', popup: '<b style="color:#2a6b8a">Marine St Courts</b><br>Pro-level · 6 courts · Lights<br><i style="color:#4a5e3a">Best: A / Open pickup</i>' },
  { id: 'mb-pier',      name: 'MB Pier Courts',           sub: 'Manhattan Beach',    tag: 'Iconic',         lat: 33.8842, lon: -118.4097, color: '#2a6b8a', popup: '<b style="color:#2a6b8a">Manhattan Beach Pier Courts</b><br>Most famous courts in the world<br><i style="color:#4a5e3a">AVP history · All levels</i>' },
  { id: '22nd',         name: '22nd St Courts',           sub: 'Manhattan Beach',    tag: 'High Level',     lat: 33.8817, lon: -118.4117, color: '#2a6b8a', popup: '<b style="color:#2a6b8a">22nd St Courts</b><br>High-intermediate · 4 courts<br><i style="color:#4a5e3a">Best: BB / A competitive</i>' },
  { id: '26th',         name: '26th St Courts',           sub: 'Manhattan Beach',    tag: 'Competitive',    lat: 33.8858, lon: -118.4110, color: '#2a6b8a', popup: '<b style="color:#2a6b8a">26th St Courts</b><br>Strong competitive scene<br><i style="color:#4a5e3a">Best: A / competitive</i>' },
  // ── HERMOSA BEACH ── (primary)
  { id: 'hermosa-pier', name: 'Hermosa Pier Courts',      sub: 'Hermosa Beach ⭐',   tag: 'Social · Home',  lat: 33.8622, lon: -118.4023, color: '#c4614a', popup: '<b style="color:#c4614a">Hermosa Pier Courts</b><br>⭐ Prime location · Challenge court culture<br>Best social scene on the Strand<br><i style="color:#c4614a">All day action · All levels</i>' },
  { id: 'hermosa-12th', name: '12th St Courts',           sub: 'Hermosa Beach',      tag: 'Intermediate',   lat: 33.8602, lon: -118.4018, color: '#c4614a', popup: '<b style="color:#c4614a">12th St Courts</b><br>Great intermediate scene<br><i style="color:#c4614a">Best: BB level</i>' },
  { id: 'hermosa-6th',  name: '6th St Courts',            sub: 'Hermosa Beach',      tag: 'Mixed',          lat: 33.8568, lon: -118.3999, color: '#c4614a', popup: '<b style="color:#c4614a">6th St Courts</b><br>Mixed levels · Good scene<br><i style="color:#c4614a">Best: B / BB</i>' },
  { id: 'hermosa-1st',  name: '1st St Courts',            sub: 'Hermosa Beach',      tag: 'South End',      lat: 33.8539, lon: -118.3990, color: '#c4614a', popup: '<b style="color:#c4614a">1st St Courts</b><br>Quieter · Great for practice<br><i style="color:#c4614a">All levels welcome</i>' },
  // ── KNOB HILL & AVE G (Redondo Esplanade) ──
  { id: 'knob-hill',    name: 'Knob Hill Courts',         sub: 'Redondo Beach · 811 Esplanade', tag: 'Thu/Sat/Sun Games', lat: 33.8285, lon: -118.3905, color: '#4a5e3a', popup: '<b style="color:#4a5e3a">Knob Hill Courts</b><br>811 Esplanade, Redondo Beach<br>📅 Thu 2pm · Sat/Sun 2pm (Int/Adv)<br><i style="color:#4a5e3a">Organized pickup · All welcome</i>' },
  { id: 'ave-g',        name: 'Ave G Courts',             sub: 'Redondo Beach · Esplanade',     tag: 'Sat/Sun Beginner', lat: 33.8241, lon: -118.3897, color: '#4a5e3a', popup: '<b style="color:#4a5e3a">Ave G Courts</b><br>Esplanade near Ave G, Redondo Beach<br>📅 Sat/Sun 2pm (Beginners)<br><i style="color:#4a5e3a">Friendly beginner scene</i>' },
  { id: 'redondo',      name: 'Redondo Esplanade Courts', sub: 'Redondo Beach',      tag: 'Wind Protected', lat: 33.8304, lon: -118.3905, color: '#4a5e3a', popup: '<b style="color:#4a5e3a">Redondo Esplanade Courts</b><br>Wind-protected by breakwater<br><i style="color:#4a5e3a">Best on heavy wind days · All levels</i>' },
  { id: 'torrance',     name: 'Torrance Beach Courts',    sub: 'Redondo / Torrance', tag: 'Chill Vibes',    lat: 33.8380, lon: -118.3900, color: '#4a5e3a', popup: '<b style="color:#4a5e3a">Torrance Beach Courts</b><br>Laid-back · Less crowded<br><i style="color:#4a5e3a">Beginners welcome</i>' },
  // ── DOCKWEILER ──
  { id: 'dockweiler',   name: 'Dockweiler Courts',        sub: 'Playa del Rey',      tag: 'Night Play',     lat: 33.9297, lon: -118.4272, color: '#8b7355', popup: '<b style="color:#8b7355">Dockweiler Courts</b><br>Lit courts · Fire pits<br><i style="color:#8b7355">Great evening sessions</i>' },
]

export const CREAMY_BOYS = [
  { id: 'cb-hermosa', name: 'Creamy Boys · Hermosa',   lat: 33.8619, lon: -118.3997, addr: '1136 Hermosa Ave',   hours: 'Mon–Thu 12–10pm · Fri–Sat 12–11pm · Sun 12–10pm' },
  { id: 'cb-elseg',   name: 'Creamy Boys · El Segundo', lat: 33.9189, lon: -118.4167, addr: '118 W Grand Ave',    hours: 'Mon–Thu 12–10pm · Fri–Sat 12–11pm · Sun 12–10pm' },
]

const icon = (color, active, size) => {
  const s = size || (active ? 13 : 9)
  return L.divIcon({
    html: `<div style="width:${s}px;height:${s}px;border-radius:50%;background:${color};border:2px solid ${color}50;box-shadow:0 0 ${active?10:4}px ${color}80;"></div>`,
    className: '', iconSize: [s, s], iconAnchor: [s/2, s/2],
  })
}

export default function SpotMap({ activeSpot, onSpotClick }) {
  const mapRef  = useRef(null)
  const mapObj  = useRef(null)
  const markers = useRef({})

  useEffect(() => {
    if (mapObj.current) return
    // Center on Hermosa — primary location
    const map = L.map(mapRef.current, { center: [33.862, -118.401], zoom: 13, zoomControl: false })
    L.control.zoom({ position: 'bottomright' }).addTo(map)
    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; <a href="https://carto.com/">CARTO</a>', subdomains: 'abcd', maxZoom: 19,
    }).addTo(map)

    // NOAA Buoy markers
    ;[
      { lat: 33.749, lon: -119.053, id: '46025', desc: 'Outer Scout · Period + Direction', color: '#2a6b8a' },
      { lat: 33.855, lon: -118.633, id: '46221', desc: 'Inner Confirm · Wave Height',      color: '#4a5e3a' },
    ].forEach(b => {
      L.marker([b.lat, b.lon], {
        icon: L.divIcon({ html: `<div style="width:8px;height:8px;border-radius:50%;background:${b.color};border:2px solid white;box-shadow:0 0 5px ${b.color};"></div>`, className:'', iconSize:[8,8], iconAnchor:[4,4] })
      }).addTo(map).bindPopup(`<b style="color:${b.color}">Buoy ${b.id}</b><br><span style="color:#5c4f3a;font-size:11px">${b.desc}</span>`)
    })

    // Creamy Boys — pink dots 🍦
    CREAMY_BOYS.forEach(cb => {
      L.marker([cb.lat, cb.lon], {
        icon: L.divIcon({
          html: `<div style="width:12px;height:12px;border-radius:50%;background:#f472b6;border:2px solid #fbcfe8;box-shadow:0 0 8px #f472b680;font-size:8px;display:flex;align-items:center;justify-content:center;">🍦</div>`,
          className: '', iconSize:[12,12], iconAnchor:[6,6],
        })
      }).addTo(map).bindPopup(`
        <b style="color:#db2777">${cb.name}</b><br>
        <span style="color:#5c4f3a;font-size:11px">
          ${cb.addr}<br>
          🕐 ${cb.hours}<br>
          <span style="color:#db2777">⭐ 4.8 rating</span>
        </span>`)
    })

    // Volleyball spot markers
    SPOTS.forEach(spot => {
      const isHome = spot.id === 'hermosa-pier'
      const m = L.marker([spot.lat, spot.lon], { icon: icon(spot.color, isHome, isHome ? 15 : undefined) })
        .addTo(map)
        .bindPopup(`<div style="font-family:'DM Mono',monospace;font-size:12px;line-height:1.6">${spot.popup}</div>`, { maxWidth: 240 })
      m.on('click', () => onSpotClick(spot.id))
      markers.current[spot.id] = { m, color: spot.color }
    })
    mapObj.current = map
  }, [])

  useEffect(() => {
    SPOTS.forEach(spot => {
      const entry = markers.current[spot.id]
      if (!entry) return
      const active = spot.id === activeSpot
      const isHome = spot.id === 'hermosa-pier'
      entry.m.setIcon(icon(entry.color, active || isHome, active ? 15 : isHome ? 15 : undefined))
      if (active) { mapObj.current?.flyTo([spot.lat, spot.lon], 15, { duration: 1.2 }); entry.m.openPopup() }
    })
  }, [activeSpot])

  return <div ref={mapRef} style={{ height: '480px', borderRadius: '12px', border: '1px solid var(--border)', overflow: 'hidden' }} />
}
