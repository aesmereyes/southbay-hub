const COMPASS = ['N','NNE','NE','ENE','E','ESE','SE','SSE','S','SSW','SW','WSW','W','WNW','NW','NNW']
export const degToCompass = (deg) => deg != null ? COMPASS[Math.round(deg / 22.5) % 16] : '—'

// ── SURF SCORING ───────────────────────────────────────────────────
// heightFt → from buoy 46221 (inner confirm)
// periodS  → from buoy 46025 (offshore truth)
export function calcSurfScore({ heightFt, periodS, windMph }) {
  if (!heightFt || !periodS) return 0
  if (heightFt > 8) return 1
  if (periodS > 16) return 3      // South Bay: walls out

  let score = 5
  if      (heightFt >= 3 && heightFt <= 6) score += 2
  else if (heightFt >= 1 && heightFt < 2)  score -= 1
  else if (heightFt < 1)                   score -= 2

  if      (periodS >= 12 && periodS <= 16) score += 2
  else if (periodS >= 9  && periodS < 12)  score += 1
  else if (periodS < 8)                    score -= 1

  if      (windMph < 8)  score += 1
  else if (windMph > 20) score -= 2
  else if (windMph > 12) score -= 1

  return Math.max(0, Math.min(10, Math.round(score)))
}

export function surfQuality(score, heightFt, periodS) {
  if (!heightFt) return { label: 'NO DATA', color: '#9a8a72', bg: 'rgba(154,138,114,0.1)' }
  if (heightFt > 8)   return { label: 'CLOSED OUT', color: '#c4614a', bg: 'rgba(196,97,74,0.1)' }
  if (periodS > 16)   return { label: 'WALLED OUT', color: '#d4824a', bg: 'rgba(212,130,74,0.1)' }
  if (score >= 8)     return { label: 'EPIC',        color: '#4a5e3a', bg: 'rgba(74,94,58,0.1)'  }
  if (score >= 6)     return { label: 'GOOD',        color: '#2a6b8a', bg: 'rgba(42,107,138,0.1)'}
  if (score >= 4)     return { label: 'FAIR',        color: '#d4824a', bg: 'rgba(212,130,74,0.1)'}
  return                     { label: 'POOR',        color: '#c4614a', bg: 'rgba(196,97,74,0.1)' }
}

export function surfAdvice({ score, heightFt, periodS, windMph, mwdDeg }) {
  if (!heightFt) return 'Buoy data updating — check back in a few minutes.'
  const dir = degToCompass(mwdDeg)
  if (heightFt > 8)  return `Closed out at ${heightFt.toFixed(1)}ft. Most breaks unsurfable today.`
  if (periodS > 16)  return `${Math.round(periodS)}s period from ${dir} is walling the beach break. Try jetty-protected spots.`
  if (score >= 8)    return `${dir} swell at ${heightFt.toFixed(1)}ft / ${Math.round(periodS)}s — conditions are firing. Go now.`
  if (score >= 6)    return windMph < 8 ? `Glassy ${heightFt.toFixed(1)}ft faces with ${Math.round(periodS)}s period. Solid session.`
                                        : `${heightFt.toFixed(1)}ft with ${windMph.toFixed(0)}mph wind texture. Worth paddling out.`
  if (score >= 4)    return `Survivable ${heightFt.toFixed(1)}ft / ${Math.round(periodS)}s. Manage expectations.`
  return `${heightFt.toFixed(1)}ft slop. Better days are coming — check the trend.`
}

// ── VOLLEYBALL SCORING ─────────────────────────────────────────────
export function calcVolleyScore({ windMph, cloudPct }) {
  if (windMph == null) return 0
  let score = 8
  if      (windMph <= 5)  score += 2
  else if (windMph <= 12) score += 0
  else if (windMph <= 20) score -= 2
  else                    score -= 5
  if (cloudPct > 80) score -= 1
  return Math.max(0, Math.min(10, Math.round(score)))
}

export function windCondition(mph) {
  if (mph == null) return { label: 'NO DATA', color: '#9a8a72', bg: 'rgba(154,138,114,0.1)' }
  if (mph <= 5)   return { label: 'PURE',      color: '#4a5e3a', bg: 'rgba(74,94,58,0.1)'   }
  if (mph <= 12)  return { label: 'BREEZY',    color: '#2a6b8a', bg: 'rgba(42,107,138,0.1)' }
  if (mph <= 20)  return { label: 'HEAVY',     color: '#d4824a', bg: 'rgba(212,130,74,0.1)' }
  return                 { label: 'BLOWN OUT', color: '#c4614a', bg: 'rgba(196,97,74,0.1)'  }
}

export function windDriftAdvice({ windMph, windDirDeg }) {
  if (windMph == null) return 'Weather data loading...'
  const dir = degToCompass(windDirDeg)
  const isNorth = windDirDeg >= 315 || windDirDeg <= 45
  const isSouth = windDirDeg > 135 && windDirDeg <= 225
  const drift = isNorth ? 'ball drifts south' : isSouth ? 'ball drifts north'
              : windDirDeg <= 135 ? 'offshore pull (great for serving)' : 'onshore push'

  if (windMph <= 5)  return `${dir} at ${windMph.toFixed(0)}mph — zero drift. Perfect setting conditions.`
  if (windMph <= 12) return `${dir} at ${windMph.toFixed(0)}mph — ${drift}. Use the wind on float serves.`
  if (windMph <= 20) return `${dir} at ${windMph.toFixed(0)}mph — ${drift}. Keep sets low and 3ft off the net.`
  return `${dir} at ${windMph.toFixed(0)}mph — ${drift}. Sand flying. Hero serves only.`
}

// ── NOAA TEXT PARSER ───────────────────────────────────────────────
export function parseNOAAText(raw) {
  if (!raw) return null
  const lines = raw.trim().split('\n').filter(l => !l.startsWith('#'))
  if (lines.length < 3) return null
  const headers = lines[0].trim().split(/\s+/)
  for (const line of lines.slice(2)) {
    const vals = line.trim().split(/\s+/)
    const row = {}
    headers.forEach((h, i) => { row[h] = vals[i] })
    const get = (k) => { const v = parseFloat(row[k]); return (isNaN(v) || v >= 99) ? null : v }
    const wvht = get('WVHT'), dpd = get('DPD')
    if (wvht === null && dpd === null) continue
    const wtmp = get('WTMP'), atmp = get('ATMP'), wspd = get('WSPD')
    return {
      wvhtFt:  wvht != null ? +(wvht * 3.281).toFixed(2) : null,
      dpdS:    dpd,
      mwdDeg:  get('MWD'),
      wspdMph: wspd != null ? +(wspd * 2.237).toFixed(1) : null,
      wdirDeg: get('WDIR'),
      wtmpF:   wtmp != null ? +((wtmp * 9/5) + 32).toFixed(1) : null,
      atmpF:   atmp != null ? +((atmp * 9/5) + 32).toFixed(1) : null,
      time:    `${row['YY']||row['#YY']}-${row['MM']}-${row['DD']} ${row['hh']}:${row['mm']} UTC`,
    }
  }
  return null
}
