import { degToCompass } from './logic'

// Station metadata — what each one means for surfers
const STATION_META = {
  '46025': {
    name: 'Santa Monica Basin',
    nickname: 'The Outer Scout',
    color: '#2a6b8a',
    depth: '890m deep water',
    relevance: 'North Bay & South Bay',
    surferTip: 'Use this for period & direction — unfiltered swell before it hits the shelf. If 46025 shows 16s+, big energy is coming.',
    icon: '🌊',
  },
  '46221': {
    name: 'Santa Monica Bay',
    nickname: 'The Inner Confirm',
    color: '#4a5e3a',
    depth: '387m mid-bay',
    relevance: 'Manhattan · Hermosa · Redondo',
    surferTip: 'Use this for actual height — tells you what made it through Catalina\'s shadow. If smaller than 46025, the islands blocked it.',
    icon: '📡',
  },
  '46268': {
    name: 'Topanga Nearshore',
    nickname: 'The North Sentinel',
    color: '#6ab4a0',
    depth: '~20m nearshore',
    relevance: 'Malibu · Santa Monica · Venice',
    surferTip: 'NW swells hit here first. If Topanga is already firing and period is 12s+, South Bay gets it within the hour.',
    icon: '🏄',
  },
  'ICAC1': {
    name: 'Santa Monica Pier',
    nickname: 'The Shore Station',
    color: '#8b7355',
    depth: 'Shore level',
    relevance: 'Wind & tide reference',
    surferTip: 'Wind and tide data right at the pier. Cross-reference wind here vs Open-Meteo — if they match, trust it.',
    icon: '🌬️',
  },
  '46222': {
    name: 'San Pedro',
    nickname: 'The South Sentinel',
    color: '#d4824a',
    depth: '483m deep water',
    relevance: 'South Bay south swells',
    surferTip: 'South swells come up from below Palos Verdes. If 46222 is showing height and period, Redondo and south Hermosa are on.',
    icon: '🧭',
  },
  '46253': {
    name: 'San Pedro South',
    nickname: 'Redondo\'s Backyard',
    color: '#c4614a',
    depth: '66m nearshore',
    relevance: 'Redondo · Torrance Beach',
    surferTip: 'Closest nearshore station to Redondo. If this shows wave height, Redondo Breakwater and King Harbor are already firing.',
    icon: '🎯',
  },
}

const ORDER = ['46025', '46221', '46268', 'ICAC1', '46222', '46253']

function StatPill({ label, value, unit, color }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '8px 10px', background: 'rgba(139,115,85,0.06)', borderRadius: '8px', minWidth: '72px' }}>
      <div style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '3px' }}>{label}</div>
      <div style={{ fontFamily: 'var(--font-mono)', fontSize: '16px', fontWeight: 600, color: color || 'var(--text-mid)', lineHeight: 1 }}>
        {value ?? <span style={{ color: 'var(--text-light)', fontSize: '12px' }}>N/A</span>}
      </div>
      {unit && <div style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', color: 'var(--text-muted)', marginTop: '1px' }}>{unit}</div>}
    </div>
  )
}

function BuoyCard({ id, station }) {
  const meta = STATION_META[id]
  const d = station?.data
  const ok = station?.ok

  return (
    <div style={{
      background: 'var(--sand-dark)',
      border: `1px solid ${ok ? `${meta.color}30` : 'var(--border-soft)'}`,
      borderRadius: '12px',
      padding: '16px 18px',
      position: 'relative',
      overflow: 'hidden',
    }}>
      {/* Color bar top */}
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: '3px', background: ok ? meta.color : 'var(--dune)', opacity: ok ? 1 : 0.3 }} />

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '10px' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <span style={{ fontSize: '16px' }}>{meta.icon}</span>
            <span style={{ fontFamily: 'var(--font-display)', fontSize: '14px', fontWeight: 700, color: ok ? meta.color : 'var(--text-muted)' }}>{meta.nickname}</span>
          </div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-muted)', marginTop: '2px' }}>
            {id} · {meta.name}
          </div>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '3px' }}>
          <span style={{
            fontFamily: 'var(--font-mono)', fontSize: '9px', padding: '2px 8px', borderRadius: '10px', textTransform: 'uppercase', letterSpacing: '0.05em',
            background: ok ? `${meta.color}15` : 'rgba(139,115,85,0.1)',
            color: ok ? meta.color : 'var(--text-muted)',
          }}>
            {ok ? '● Live' : '○ No data'}
          </span>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', color: 'var(--text-light)' }}>{meta.depth}</span>
        </div>
      </div>

      {/* Data pills */}
      <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', marginBottom: '12px' }}>
        <StatPill label="Height" value={d?.wvht_ft?.toFixed(1)} unit="ft" color={ok ? meta.color : undefined} />
        <StatPill label="Period" value={d?.dpd_s ? Math.round(d.dpd_s) : null} unit="s" color={ok ? meta.color : undefined} />
        <StatPill label="Direction" value={d?.mwd_deg != null ? degToCompass(d.mwd_deg) : null} color={ok ? meta.color : undefined} />
        <StatPill label="Wind" value={d?.wspd_mph?.toFixed(0)} unit="mph" />
        {d?.wtmp_f && <StatPill label="Water" value={Math.round(d.wtmp_f)} unit="°F" color="#2a6b8a" />}
      </div>

      {/* Relevance */}
      <div style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: meta.color, marginBottom: '6px', fontWeight: 500 }}>
        📍 {meta.relevance}
      </div>

      {/* Surfer tip */}
      <div style={{ fontFamily: 'var(--font-body)', fontSize: '11px', color: 'var(--text-muted)', lineHeight: 1.5, fontStyle: 'italic', borderTop: '1px solid var(--border-soft)', paddingTop: '8px' }}>
        {meta.surferTip}
      </div>

      {/* Timestamp */}
      {d?.timestamp && (
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', color: 'var(--text-light)', marginTop: '8px', textAlign: 'right' }}>
          {d.timestamp}
        </div>
      )}
    </div>
  )
}

export default function BuoyDashboard({ stations, fetchedAt, errors }) {
  if (!stations) return null

  const fetchedAge = fetchedAt
    ? Math.round((Date.now() - new Date(fetchedAt)) / 60000)
    : null

  const liveCount = ORDER.filter(id => stations[id]?.ok).length

  return (
    <section style={{ marginBottom: '28px', position: 'relative', zIndex: 1 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
        <div>
          <span style={{ fontFamily: 'var(--font-display)', fontSize: '20px', fontWeight: 700, color: 'var(--text)' }}>
            Buoy Network
          </span>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-muted)', marginLeft: '10px', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
            {liveCount}/{ORDER.length} stations live
          </span>
        </div>
        <div style={{ flex: 1, height: '1px', background: 'var(--border)' }} />
        {fetchedAge !== null && (
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: fetchedAge > 90 ? '#c4614a' : '#4a5e3a', whiteSpace: 'nowrap' }}>
            {fetchedAge < 2 ? 'just updated' : `updated ${fetchedAge < 60 ? fetchedAge + 'min' : Math.floor(fetchedAge/60) + 'h ' + (fetchedAge%60) + 'm'} ago`}
          </div>
        )}
      </div>

      {/* Legend */}
      <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', marginBottom: '14px', padding: '10px 14px', background: 'var(--sand-dark)', border: '1px solid var(--border-soft)', borderRadius: '10px' }}>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-muted)', marginRight: '6px', textTransform: 'uppercase', letterSpacing: '0.06em', alignSelf: 'center' }}>How to read:</div>
        {[
          { color: '#2a6b8a', text: '46025 + 46221 → Surf score inputs' },
          { color: '#6ab4a0', text: '46268 → NW swell early warning' },
          { color: '#c4614a', text: '46253 → Redondo real-time' },
          { color: '#d4824a', text: '46222 → South swell detector' },
        ].map(l => (
          <div key={l.text} style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
            <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: l.color, flexShrink: 0 }} />
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-mid)' }}>{l.text}</span>
          </div>
        ))}
      </div>

      {/* Cards grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px' }}>
        {ORDER.map(id => (
          <BuoyCard key={id} id={id} station={stations[id]} />
        ))}
      </div>
    </section>
  )
}
