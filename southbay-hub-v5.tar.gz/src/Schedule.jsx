const SCHEDULE = [
  {
    day: 'Thursday',
    short: 'Thu',
    events: [
      { time: '2:00 PM', location: 'Knob Hill Courts', sub: '811 Esplanade, Redondo Beach', level: 'All Levels', color: '#4a5e3a', note: 'Weekly pickup — all welcome' },
    ],
  },
  {
    day: 'Saturday',
    short: 'Sat',
    events: [
      { time: '2:00 PM', location: 'Knob Hill Courts',  sub: '811 Esplanade, Redondo Beach', level: 'Int / Adv', color: '#d4824a', note: 'Intermediate & Advanced' },
      { time: '2:00 PM', location: 'Ave G Courts',       sub: 'Esplanade near Ave G, Redondo', level: 'Beginner', color: '#2a6b8a', note: 'Beginners welcome · Friendly vibe' },
    ],
  },
  {
    day: 'Sunday',
    short: 'Sun',
    events: [
      { time: '2:00 PM', location: 'Knob Hill Courts',  sub: '811 Esplanade, Redondo Beach', level: 'Int / Adv', color: '#d4824a', note: 'Intermediate & Advanced' },
      { time: '2:00 PM', location: 'Ave G Courts',       sub: 'Esplanade near Ave G, Redondo', level: 'Beginner', color: '#2a6b8a', note: 'Beginners welcome · Friendly vibe' },
    ],
  },
]

const LEVEL_COLOR = {
  'All Levels': '#4a5e3a',
  'Int / Adv':  '#d4824a',
  'Beginner':   '#2a6b8a',
}

// Which day is today? Highlight it.
const TODAY = new Date().toLocaleDateString('en-US', { timeZone: 'America/Los_Angeles', weekday: 'long' })

export default function Schedule() {
  return (
    <section style={{ marginBottom: '28px', position: 'relative', zIndex: 1 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
        <span style={{ fontFamily: 'var(--font-display)', fontSize: '20px', fontWeight: 700, color: 'var(--text)' }}>
          Weekly Schedule
        </span>
        <div style={{ flex: 1, height: '1px', background: 'var(--border)' }} />
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
          Knob Hill · Ave G · Redondo
        </span>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px' }}>
        {SCHEDULE.map(day => {
          const isToday = day.day === TODAY
          return (
            <div key={day.day} style={{
              background: isToday ? 'var(--sand-deeper)' : 'var(--sand-dark)',
              border: `1px solid ${isToday ? 'var(--driftwood)' : 'var(--border-soft)'}`,
              borderRadius: '12px',
              padding: '16px 18px',
              position: 'relative',
              overflow: 'hidden',
            }}>
              {isToday && (
                <div style={{ position: 'absolute', top: '10px', right: '12px', fontFamily: 'var(--font-mono)', fontSize: '9px', background: 'var(--driftwood)', color: 'white', padding: '2px 8px', borderRadius: '10px', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Today</div>
              )}
              <div style={{ fontFamily: 'var(--font-display)', fontSize: '18px', fontWeight: 700, color: isToday ? 'var(--driftwood)' : 'var(--text-mid)', marginBottom: '12px' }}>
                {day.day}
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                {day.events.map((ev, i) => (
                  <div key={i} style={{ background: `${ev.color}0d`, border: `1px solid ${ev.color}25`, borderRadius: '8px', padding: '10px 12px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' }}>
                      <span style={{ fontFamily: 'var(--font-mono)', fontSize: '13px', fontWeight: 600, color: 'var(--text)' }}>⏰ {ev.time}</span>
                      <span style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', padding: '2px 8px', borderRadius: '10px', background: `${ev.color}18`, color: ev.color, fontWeight: 600, letterSpacing: '0.04em' }}>{ev.level}</span>
                    </div>
                    <div style={{ fontFamily: 'var(--font-body)', fontSize: '13px', color: 'var(--text-mid)', fontWeight: 500 }}>{ev.location}</div>
                    <div style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-muted)', marginTop: '2px' }}>{ev.sub}</div>
                    <div style={{ fontFamily: 'var(--font-body)', fontSize: '11px', color: ev.color, marginTop: '5px', fontStyle: 'italic' }}>{ev.note}</div>
                  </div>
                ))}
              </div>
            </div>
          )
        })}
      </div>
    </section>
  )
}
