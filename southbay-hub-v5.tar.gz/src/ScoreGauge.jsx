export default function ScoreGauge({ score, color, size = 130 }) {
  const r = 48, cx = size / 2, cy = size / 2, strokeW = 7
  const polar = (a) => {
    const rad = (a - 90) * (Math.PI / 180)
    return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) }
  }
  const arc = (s, e) => {
    const a = polar(s), b = polar(e)
    return `M ${a.x} ${a.y} A ${r} ${r} 0 ${e - s > 180 ? 1 : 0} 1 ${b.x} ${b.y}`
  }
  const start = 135, sweep = 270
  const fillEnd = start + (score / 10) * sweep

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}
      role="img" aria-label={`Score ${score} out of 10`}>
      <path d={arc(start, start + sweep)} fill="none"
        stroke="rgba(139,115,85,0.15)" strokeWidth={strokeW} strokeLinecap="round" />
      {score > 0 && (
        <path d={arc(start, fillEnd)} fill="none"
          stroke={color} strokeWidth={strokeW} strokeLinecap="round"
          style={{ filter: `drop-shadow(0 0 4px ${color}60)` }} />
      )}
      <text x={cx} y={cy - 3} textAnchor="middle" dominantBaseline="middle"
        fill={color} fontSize="34" fontFamily="'Playfair Display', serif" fontWeight="700">
        {score}
      </text>
      <text x={cx} y={cy + 20} textAnchor="middle"
        fill="var(--text-muted)" fontSize="11" fontFamily="'DM Mono', monospace">
        /10
      </text>
    </svg>
  )
}
