import { useState } from 'react'

const SEED = [
  { id: 1, group: 'MB Morning Grind',   level: 'A',    location: 'Marine St Courts',     time: 'Today · 7:00 AM',    contact: 'https://wa.me/13105550001' },
  { id: 2, group: 'Hermosa Kings',      level: 'Open', location: 'Hermosa Pier Courts',  time: 'Today · 10:00 AM',   contact: 'https://instagram.com/'    },
  { id: 3, group: 'Sunset Rally',       level: 'BB',   location: '22nd St Courts',       time: 'Today · 5:30 PM',    contact: 'https://wa.me/13105550002' },
  { id: 4, group: 'Redondo Regulars',   level: 'B',    location: 'Redondo Esplanade',    time: 'Today · 9:00 AM',    contact: 'https://wa.me/13105550003' },
  { id: 5, group: 'AVP Hopefuls',       level: 'A',    location: 'Marine St Courts',     time: 'Tomorrow · 8:00 AM', contact: 'https://instagram.com/'    },
  { id: 6, group: 'Dockweiler Nights',  level: 'Open', location: 'Dockweiler Courts',    time: 'Tonight · 6:30 PM',  contact: 'https://wa.me/13105550004' },
]

const LVL = {
  B:    { color: '#8b7355', bg: 'rgba(139,115,85,0.12)',  bar: '#8b7355' },
  BB:   { color: '#2a6b8a', bg: 'rgba(42,107,138,0.12)', bar: '#2a6b8a' },
  A:    { color: '#d4824a', bg: 'rgba(212,130,74,0.12)',  bar: '#d4824a' },
  Open: { color: '#4a5e3a', bg: 'rgba(74,94,58,0.12)',   bar: '#4a5e3a' },
}

function Card({ m }) {
  const lvl = LVL[m.level] || LVL.B
  const label = m.contact?.includes('wa.me') ? '💬 Join WhatsApp' : '📸 Find on Instagram'
  return (
    <div style={{ background: 'var(--sand-dark)', border: '1px solid var(--border-soft)', borderRadius: '12px', padding: '18px 20px', position: 'relative', overflow: 'hidden' }}
      onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--dune)'}
      onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border-soft)'}>
      <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: '3px', background: lvl.bar, borderRadius: '3px 0 0 3px' }} />
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '10px' }}>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: '16px', fontWeight: 600, color: 'var(--text)' }}>{m.group}</div>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', padding: '3px 10px', borderRadius: '20px', background: lvl.bg, color: lvl.color, fontWeight: 500 }}>{m.level}</span>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', marginBottom: '14px' }}>
        <div style={{ fontSize: '13px', color: 'var(--text-mid)', fontFamily: 'var(--font-body)' }}>📍 {m.location}</div>
        <div style={{ fontSize: '13px', color: 'var(--text-mid)', fontFamily: 'var(--font-body)' }}>🕐 {m.time}</div>
      </div>
      <a href={m.contact} target="_blank" rel="noopener noreferrer"
        style={{ display: 'block', textAlign: 'center', padding: '9px', background: 'transparent', border: '1px solid var(--dune)', borderRadius: '8px', color: 'var(--driftwood)', fontFamily: 'var(--font-mono)', fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.06em', textDecoration: 'none', transition: 'all 0.2s' }}
        onMouseEnter={e => { e.target.style.background = 'var(--dune)'; e.target.style.color = 'var(--sand)' }}
        onMouseLeave={e => { e.target.style.background = 'transparent'; e.target.style.color = 'var(--driftwood)' }}>
        {label}
      </a>
    </div>
  )
}

function Modal({ onClose, onAdd }) {
  const [f, setF] = useState({ group: '', level: 'BB', location: 'Marine St Courts', time: '', contact: '' })
  const set = (k, v) => setF(p => ({ ...p, [k]: v }))
  const input = { width: '100%', padding: '10px 14px', background: 'var(--sand)', border: '1px solid var(--dune)', borderRadius: '8px', color: 'var(--text)', fontFamily: 'var(--font-mono)', fontSize: '13px', outline: 'none' }

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(44,36,22,0.5)', zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center', backdropFilter: 'blur(4px)' }}
      onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{ background: 'var(--sand)', border: '1px solid var(--border)', borderRadius: '16px', padding: '32px 36px', width: '100%', maxWidth: '460px', position: 'relative' }}>
        <button onClick={onClose} style={{ position: 'absolute', top: '14px', right: '16px', background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer', color: 'var(--text-muted)' }}>✕</button>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: '22px', fontWeight: 700, color: 'var(--text)', marginBottom: '24px' }}>Post a Game</div>
        {[
          { label: 'Group Name', key: 'group', type: 'text', ph: 'e.g. MB Morning Crew' },
          { label: 'Time',       key: 'time',  type: 'text', ph: 'e.g. Today 4:00 PM'   },
          { label: 'Contact (WhatsApp / Instagram)', key: 'contact', type: 'url', ph: 'https://wa.me/...' },
        ].map(field => (
          <div key={field.key} style={{ marginBottom: '14px' }}>
            <label style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.1em', display: 'block', marginBottom: '6px' }}>{field.label}</label>
            <input style={input} type={field.type} placeholder={field.ph} value={f[field.key]}
              onChange={e => set(field.key, e.target.value)}
              onFocus={e => e.target.style.borderColor = 'var(--ocean)'}
              onBlur={e => e.target.style.borderColor = 'var(--dune)'} />
          </div>
        ))}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px', marginBottom: '14px' }}>
          {[
            { label: 'Level', key: 'level', opts: ['B','BB','A','Open'] },
            { label: 'Location', key: 'location', opts: ['Marine St Courts','MB Pier Courts','22nd St Courts','26th St Courts','Hermosa Pier Courts','12th St Courts','6th St Courts','Redondo Esplanade','Torrance Beach','Dockweiler Courts'] },
          ].map(sel => (
            <div key={sel.key}>
              <label style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.1em', display: 'block', marginBottom: '6px' }}>{sel.label}</label>
              <select style={input} value={f[sel.key]} onChange={e => set(sel.key, e.target.value)}>
                {sel.opts.map(o => <option key={o}>{o}</option>)}
              </select>
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', gap: '12px', marginTop: '8px' }}>
          <button onClick={onClose} style={{ flex: 1, padding: '10px', background: 'transparent', border: '1px solid var(--dune)', borderRadius: '8px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', fontSize: '12px', cursor: 'pointer' }}>Cancel</button>
          <button onClick={() => { if (f.group && f.time) { onAdd({ ...f, id: Date.now() }); onClose() } }}
            style={{ flex: 2, padding: '10px', background: 'var(--ocean)', border: 'none', borderRadius: '8px', color: 'white', fontFamily: 'var(--font-display)', fontSize: '15px', fontWeight: 700, cursor: 'pointer' }}>
            Post It
          </button>
        </div>
      </div>
    </div>
  )
}

export default function MeetupBoard() {
  const [meetups, setMeetups] = useState(SEED)
  const [modal, setModal] = useState(false)
  return (
    <section style={{ position: 'relative', zIndex: 1 }}>
      <div style={{ display: 'flex', alignItems: 'center', marginBottom: '14px', gap: '16px' }}>
        <span style={{ fontFamily: 'var(--font-display)', fontSize: '20px', fontWeight: 700, color: 'var(--text)' }}>Meetup Board</span>
        <div style={{ flex: 1, height: '1px', background: 'var(--border)' }} />
        <button onClick={() => setModal(true)} style={{ fontFamily: 'var(--font-body)', fontSize: '13px', fontWeight: 500, padding: '9px 20px', background: 'var(--ocean)', color: 'white', border: 'none', borderRadius: '8px', cursor: 'pointer' }}>
          + Post Game
        </button>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(270px, 1fr))', gap: '12px', marginBottom: '40px' }}>
        {meetups.map(m => <Card key={m.id} m={m} />)}
      </div>
      {modal && <Modal onClose={() => setModal(false)} onAdd={m => setMeetups(p => [m, ...p])} />}
    </section>
  )
}
