function Tile({ emoji, label, value, unit, color }) {
  return (
    <div style={{ background: 'var(--sand-dark)', border: '1px solid var(--border-soft)', borderRadius: '10px', padding: '14px 16px' }}>
      <div style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '6px' }}>
        {emoji} {label}
      </div>
      <div style={{ fontFamily: 'var(--font-display)', fontSize: '22px', fontWeight: 600, color: color || 'var(--text-mid)', lineHeight: 1.1 }}>
        {value ?? '—'}
        {unit && <span style={{ fontSize: '12px', color: 'var(--text-muted)', fontWeight: 400, marginLeft: '3px' }}>{unit}</span>}
      </div>
    </div>
  )
}

export default function ConditionsStrip({ data }) {
  if (!data) return null
  const { cloudPct, uvIndex, tempF, waterTempF } = data
  const uvColor = uvIndex >= 8 ? '#c4614a' : uvIndex >= 6 ? '#d4824a' : '#4a5e3a'
  const vis = cloudPct < 20 ? 'High Sun' : cloudPct < 60 ? 'Partly Cloudy' : 'Overcast'

  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: '10px', margin: '0 0 20px', position: 'relative', zIndex: 1 }}>
      <Tile emoji="🌡" label="Air Temp"    value={tempF ? Math.round(tempF) : null}      unit="°F" />
      <Tile emoji="🌊" label="Water Temp"  value={waterTempF ? Math.round(waterTempF) : null} unit="°F" color="var(--ocean)" />
      <Tile emoji="☀️" label="UV Index"    value={uvIndex?.toFixed(1)}                   color={uvColor} />
      <Tile emoji="☁️" label="Cloud Cover" value={cloudPct != null ? Math.round(cloudPct) : null} unit="%" />
      <Tile emoji="👁" label="Visibility"  value={vis} color={cloudPct < 20 ? '#d4824a' : undefined} />
    </div>
  )
}
