import { useState, useEffect } from 'react'

// Curated, reliable Unsplash image IDs that load consistently
const IMAGES = [
  'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1800&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1519451241324-20b4ea2c4220?w=1800&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1473116763249-2faaef81ccda?w=1800&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1505118380757-91f5f5632de0?w=1800&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1502680390469-be75c86b636f?w=1800&auto=format&fit=crop&q=80',
]

function fmtTime(iso) {
  if (!iso) return '--:--'
  return new Date(iso).toLocaleTimeString('en-US', {
    timeZone: 'America/Los_Angeles', hour: 'numeric', minute: '2-digit', hour12: true
  })
}

function getHeadline(data, isNight) {
  if (isNight)  return { h: 'The Shore is Yours Tonight',  s: 'Lit courts open · Stars over the Pacific' }
  if (!data)    return { h: 'Reading the Water…',           s: 'Fetching live conditions' }
  const { wvhtFt, dpdS, windMph } = data
  if (wvhtFt >= 5 && dpdS >= 12) return { h: 'The Water is on Fire',     s: `${wvhtFt.toFixed(1)}ft · ${Math.round(dpdS)}s · Go now` }
  if (wvhtFt >= 3 && dpdS >= 10) return { h: 'The Water is Calling',     s: `${wvhtFt.toFixed(1)}ft faces · ${Math.round(dpdS)}s period` }
  if (wvhtFt >= 1.5)              return { h: 'Worth a Look',             s: `${wvhtFt.toFixed(1)}ft · ${windMph.toFixed(0)}mph wind` }
  if (windMph <= 8)               return { h: 'Perfect for the Sand',     s: `${windMph.toFixed(0)}mph · Ideal volleyball conditions` }
  return                                  { h: 'A Day at the Beach',       s: 'South Bay is always on' }
}

export default function HeroHeader({ data, sunriseISO, sunsetISO }) {
  const [now, setNow]     = useState(new Date())
  const [imgIdx, setImgIdx] = useState(0)
  const [imgLoaded, setImgLoaded] = useState(false)

  useEffect(() => { const t = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(t) }, [])

  // Rotate image every 12 seconds
  useEffect(() => {
    const t = setInterval(() => {
      setImgLoaded(false)
      setImgIdx(i => (i + 1) % IMAGES.length)
    }, 12000)
    return () => clearInterval(t)
  }, [])

  const timeStr = now.toLocaleTimeString('en-US', { timeZone: 'America/Los_Angeles', hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })
  const dateStr = now.toLocaleDateString('en-US', { timeZone: 'America/Los_Angeles', weekday: 'long', month: 'long', day: 'numeric' })

  let pct = 50, isNight = false, remStr = ''
  if (sunriseISO && sunsetISO) {
    const sr = new Date(sunriseISO), ss = new Date(sunsetISO)
    pct = Math.max(0, Math.min(100, ((now - sr) / (ss - sr)) * 100))
    isNight = now > ss || now < sr
    if (!isNight) {
      const rem = ss - now
      remStr = `${Math.floor(rem/3600000)}h ${Math.floor((rem%3600000)/60000)}m left`
    }
  }

  const { h, s } = getHeadline(data, isNight)

  return (
    <div style={{ position:'relative', width:'100%', height:'400px', overflow:'hidden', borderRadius:'0 0 28px 28px', marginBottom:'32px', background:'#1a3a4a' }}>
      {/* Rotating background image */}
      <img
        key={imgIdx}
        src={IMAGES[imgIdx]}
        alt="South Bay"
        onLoad={() => setImgLoaded(true)}
        style={{
          position:'absolute', inset:0, width:'100%', height:'100%',
          objectFit:'cover', objectPosition:'center 55%',
          opacity: imgLoaded ? 1 : 0,
          transition:'opacity 1.2s ease',
        }}
      />

      {/* Gradient overlay */}
      <div style={{ position:'absolute', inset:0, background:'linear-gradient(to bottom, rgba(10,20,30,0.2) 0%, rgba(10,20,30,0.5) 55%, rgba(10,20,30,0.82) 100%)' }} />

      {/* Top bar */}
      <div style={{ position:'absolute', top:0, left:0, right:0, padding:'22px 36px', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <div>
          <div style={{ fontFamily:'var(--font-display)', fontSize:'22px', fontWeight:700, color:'white', letterSpacing:'-0.01em' }}>South Bay Hub</div>
          <div style={{ fontFamily:'var(--font-body)', fontSize:'11px', color:'rgba(255,255,255,0.6)', marginTop:'2px', letterSpacing:'0.07em', textTransform:'uppercase' }}>Hermosa · Manhattan · Redondo</div>
        </div>
        {/* Image dots */}
        <div style={{ display:'flex', gap:'6px' }}>
          {IMAGES.map((_,i) => (
            <div key={i} onClick={() => { setImgLoaded(false); setImgIdx(i) }}
              style={{ width: i===imgIdx?20:6, height:6, borderRadius:'3px', background: i===imgIdx?'white':'rgba(255,255,255,0.35)', transition:'all 0.3s', cursor:'pointer' }} />
          ))}
        </div>
      </div>

      {/* Bottom glass card */}
      <div style={{
        position:'absolute', bottom:'24px', left:'50%', transform:'translateX(-50%)',
        width:'680px', maxWidth:'calc(100% - 48px)',
        background:'rgba(10,20,30,0.4)', backdropFilter:'blur(20px)',
        WebkitBackdropFilter:'blur(20px)',
        border:'1px solid rgba(255,255,255,0.12)', borderRadius:'18px',
        padding:'24px 32px',
        display:'grid', gridTemplateColumns:'1fr auto', gap:'24px', alignItems:'center',
      }}>
        <div>
          <div style={{ fontFamily:'var(--font-display)', fontSize:'34px', fontWeight:700, color:'white', lineHeight:1.15, letterSpacing:'-0.02em', marginBottom:'6px' }}>{h}</div>
          <div style={{ fontFamily:'var(--font-body)', fontSize:'13px', color:'rgba(255,255,255,0.7)', fontWeight:300 }}>{s}</div>
          {/* Sun bar */}
          <div style={{ marginTop:'16px' }}>
            <div style={{ display:'flex', justifyContent:'space-between', fontFamily:'var(--font-mono)', fontSize:'10px', color:'rgba(255,255,255,0.45)', marginBottom:'5px' }}>
              <span>🌅 {fmtTime(sunriseISO)}</span>
              <span style={{ color:'rgba(255,179,71,0.9)' }}>{remStr || (isNight ? '🌙 Night session' : '')}</span>
              <span>🌇 {fmtTime(sunsetISO)}</span>
            </div>
            <div style={{ height:'3px', background:'rgba(255,255,255,0.15)', borderRadius:'2px', position:'relative' }}>
              <div style={{ height:'100%', width:`${pct}%`, background:'linear-gradient(90deg,#FFB347,#FF6B35)', borderRadius:'2px', position:'relative', transition:'width 1s linear' }}>
                <div style={{ position:'absolute', right:'-4px', top:'50%', transform:'translateY(-50%)', width:'7px', height:'7px', background:'#FFB347', borderRadius:'50%', boxShadow:'0 0 8px #FFB347' }} />
              </div>
            </div>
          </div>
        </div>
        {/* Clock */}
        <div style={{ textAlign:'right', flexShrink:0 }}>
          <div style={{ fontFamily:'var(--font-mono)', fontSize:'40px', fontWeight:300, color:'white', lineHeight:1, letterSpacing:'0.02em' }}>{timeStr}</div>
          <div style={{ fontFamily:'var(--font-body)', fontSize:'10px', color:'rgba(255,255,255,0.45)', marginTop:'5px', textTransform:'uppercase', letterSpacing:'0.08em' }}>{dateStr}</div>
        </div>
      </div>
    </div>
  )
}
