import { useState, useEffect, useCallback, useRef } from 'react'

const BASE = import.meta.env.BASE_URL

// ── BEACH LOCATIONS ────────────────────────────────────────────────
// Each beach gets its own Marine API call for per-spot wave data
export const BEACH_SPOTS = [
  { id: 'manhattan',  name: 'Manhattan Beach', lat: 33.886, lon: -118.411, icon: '🏄' },
  { id: 'hermosa',    name: 'Hermosa Beach',   lat: 33.862, lon: -118.402, icon: '⭐' },
  { id: 'redondo',    name: 'Redondo Beach',   lat: 33.845, lon: -118.393, icon: '🌊' },
  { id: 'el-segundo', name: 'El Segundo',      lat: 33.916, lon: -118.427, icon: '🤙' },
  { id: 'torrance',   name: 'Torrance Beach',  lat: 33.835, lon: -118.387, icon: '🏖️' },
]

// Open-Meteo Marine — CORS enabled, free, no key
// Build URL for a single lat/lon
const marineUrl = (lat, lon) =>
  `https://marine-api.open-meteo.com/v1/marine` +
  `?latitude=${lat}&longitude=${lon}` +
  `&current=wave_height,wave_period,wave_direction,` +
  `wind_wave_height,wind_wave_period,` +
  `swell_wave_height,swell_wave_period,swell_wave_direction` +
  `&hourly=wave_height,wave_period,wave_direction,swell_wave_height,swell_wave_period` +
  `&timezone=America%2FLos_Angeles&forecast_days=3`

// NOAA CO-OPS API — CORS enabled, provides real water temperature
// Station 9410840 = Santa Monica Pier (closest active temp sensor to South Bay)
const WATER_TEMP_URL =
  `https://api.tidesandcurrents.noaa.gov/api/prod/datagetter` +
  `?station=9410840&product=water_temperature` +
  `&date=latest&units=english&time_zone=lst_ldt&format=json&application=SouthBayHub`

// NOAA CO-OPS Tides — today's hi/lo for Manhattan Beach reference
const TIDES_URL =
  `https://api.tidesandcurrents.noaa.gov/api/prod/datagetter` +
  `?station=9410840&product=predictions` +
  `&date=today&datum=MLLW&interval=hilo` +
  `&units=english&time_zone=lst_ldt&format=json&application=SouthBayHub`

// Open-Meteo Weather
const WEATHER_URL =
  `https://api.open-meteo.com/v1/forecast` +
  `?latitude=33.88&longitude=-118.41` +
  `&current=temperature_2m,wind_speed_10m,wind_direction_10m,cloud_cover,uv_index` +
  `&daily=sunrise,sunset` +
  `&timezone=America%2FLos_Angeles&forecast_days=2`

function mToFt(m) { return m != null ? +(m * 3.281).toFixed(1) : null }

function parseMarineResponse(res, spot) {
  const c = res.current
  return {
    id:        spot.id,
    name:      spot.name,
    icon:      spot.icon,
    waveHtFt:  mToFt(c.wave_height),
    wavePer:   c.wave_period ? +c.wave_period.toFixed(1) : null,
    waveDirDeg: c.wave_direction ?? null,
    swellHtFt: mToFt(c.swell_wave_height),
    swellPer:  c.swell_wave_period ? +c.swell_wave_period.toFixed(1) : null,
    swellDirDeg: c.swell_wave_direction ?? null,
    windWaveHtFt: mToFt(c.wind_wave_height),
    windWavePer:  c.wind_wave_period ?? null,
    // Hourly for trend (48hr)
    hourlyTimes:   res.hourly.time.slice(0, 48),
    hourlyWaveHt:  res.hourly.wave_height.slice(0, 48).map(mToFt),
    hourlyPeriod:  res.hourly.wave_period.slice(0, 48),
    hourlySwellHt: (res.hourly.swell_wave_height || []).slice(0, 48).map(mToFt),
  }
}

export function useStationData() {
  const [data, setData]         = useState(null)
  const [error, setError]       = useState(null)
  const [loading, setLoading]   = useState(true)
  const [lastFetch, setLastFetch] = useState(null)
  const timerRef = useRef(null)

  const fetchAll = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      // Fetch all in parallel: per-beach marine data + weather + water temp + tides + buoy JSON
      const marinePromises = BEACH_SPOTS.map(spot =>
        fetch(marineUrl(spot.lat, spot.lon)).then(r => r.json())
      )

      const [
        ...marineResults
      ] = await Promise.all(marinePromises)

      // Weather, water temp, tides in parallel (non-blocking failures ok)
      const [weatherRes, waterTempRes, tidesRes, buoyRes] = await Promise.allSettled([
        fetch(WEATHER_URL).then(r => r.json()),
        fetch(WATER_TEMP_URL).then(r => r.json()),
        fetch(TIDES_URL).then(r => r.json()),
        fetch(`${BASE}buoy-data.json?t=${Math.floor(Date.now()/300000)}`).then(r => r.json()),
      ])

      // Parse per-beach marine data
      const beaches = marineResults.map((res, i) => parseMarineResponse(res, BEACH_SPOTS[i]))

      // Primary surf data = Hermosa (index 1) for scoring
      const primary = beaches.find(b => b.id === 'hermosa') || beaches[0]

      // Weather
      const weather = weatherRes.status === 'fulfilled' ? weatherRes.value : null
      const wc = weather?.current
      const windMph    = wc ? +((wc.wind_speed_10m * 0.6214).toFixed(1)) : null
      const tempF      = wc ? +((wc.temperature_2m * 9/5 + 32).toFixed(1)) : null

      // Water temperature from NOAA CO-OPS
      const waterTempData = waterTempRes.status === 'fulfilled' ? waterTempRes.value : null
      const waterTempF = (() => {
        try {
          const reading = waterTempData?.data?.[0]?.v
          return reading ? +parseFloat(reading).toFixed(1) : null
        } catch { return null }
      })()

      // Tides
      const tidesData = tidesRes.status === 'fulfilled' ? tidesRes.value : null
      const tides = (() => {
        try {
          return tidesData?.predictions?.slice(0, 4).map(p => ({
            time: p.t,
            height: +parseFloat(p.v).toFixed(1),
            type: p.type === 'H' ? 'High' : 'Low',
          })) ?? []
        } catch { return [] }
      })()

      // NOAA buoy detail (bonus)
      const buoy = buoyRes.status === 'fulfilled' ? buoyRes.value : null

      setData({
        // Per-beach data — the main new feature
        beaches,
        primary,

        // Compat fields for existing components
        wvhtFt:     primary.waveHtFt,
        dpdS:       primary.wavePer,
        mwdDeg:     primary.waveDirDeg,
        swellHtFt:  primary.swellHtFt,
        swellPeriod: primary.swellPer,
        swellDirDeg: primary.swellDirDeg,
        windWaveHtFt: primary.windWaveHtFt,
        windWavePer:  primary.windWavePer,
        hourlyTimes:   primary.hourlyTimes,
        hourlyWaveHt:  primary.hourlyWaveHt,
        hourlyPeriod:  primary.hourlyPeriod,
        hourlySwellHt: primary.hourlySwellHt,

        // Weather
        windMph,
        windDirDeg:  wc?.wind_direction_10m ?? null,
        cloudPct:    wc?.cloud_cover ?? null,
        uvIndex:     wc?.uv_index ?? null,
        tempF,
        sunriseISO:  weather?.daily?.sunrise?.[0] ?? null,
        sunsetISO:   weather?.daily?.sunset?.[0]  ?? null,

        // Water temp — NOAA CO-OPS Santa Monica Pier
        waterTempF,
        waterTempStation: 'NOAA Santa Monica Pier',

        // Tides
        tides,

        // NOAA buoy detail
        stations:      buoy?.stations   ?? null,
        buoyFetchedAt: buoy?.fetched_at ?? null,
        wvhtFt21: buoy?.stations?.['46221']?.data?.wvht_ft ?? null,
        wvhtFt25: buoy?.stations?.['46025']?.data?.wvht_ft ?? null,
        b21Time:  buoy?.stations?.['46221']?.data?.timestamp ?? null,
        b25Time:  buoy?.stations?.['46025']?.data?.timestamp ?? null,
      })
      setLastFetch(new Date())
    } catch (e) {
      console.error('Fetch error:', e)
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchAll()
    timerRef.current = setInterval(fetchAll, 30 * 60 * 1000)
    return () => clearInterval(timerRef.current)
  }, [fetchAll])

  return { data, error, loading, lastFetch, refetch: fetchAll }
}
