import { useState } from 'react'
import { useStationData } from './useStationData'
import { calcSurfScore, surfQuality, surfAdvice, calcVolleyScore, windCondition, windDriftAdvice } from './logic'
import DaylightHeader  from './DaylightHeader'
import SurfCard        from './SurfCard'
import VolleyCard      from './VolleyCard'
import ConditionsStrip from './ConditionsStrip'
import SpotMap, { SPOTS } from './SpotMap'
import MeetupBoard     from './MeetupBoard'

function SectionTitle({ children }) {
  return (
    <div style={{ display:'flex', alignItems:'center', gap:'12px', margin:'0 0 14px' }}>
      <span style={{ fontFamily:'var(--font-display)', fontSize:'20px', fontWeight:700, color:'var(--text)', whiteSpace:'nowrap' }}>{children}</span>
      <div style={{ flex:1, height:'1px', background:'var(--border)' }} />
    </div>
  )
}

export default function App() {
  const { data, error, loading, lastFetch, refetch } = useStationData()
  const [activeSpot, setActiveSpot] = useState(null)

  const surfScore  = data ? calcSurfScore({ heightFt: data.wvhtFt, periodS: data.dpdS, windMph: data.windMph }) : 0
  const surfQual   = data ? surfQuality(surfScore, data.wvhtFt, data.dpdS) : null
  const surfTip    = data ? surfAdvice({ score: surfScore, heightFt: data.wvhtFt, periodS: data.dpdS, windMph: data.windMph, mwdDeg: data.mwdDeg }) : null
  const volScore   = data ? calcVolleyScore({ windMph: data.windMph, cloudPct: data.cloudPct }) : 0
  const volCond    = data ? windCondition(data.windMph) : null
  const volTip     = data ? windDriftAdvice({ windMph: data.windMph, windDirDeg: data.windDirDeg }) : null

  return (
    <div style={{ position:'relative', zIndex:1, maxWidth:'1280px', margin:'0 auto', padding:'0 28px 60px' }}>
      <DaylightHeader sunriseISO={data?.sunriseISO} sunsetISO={data?.sunsetISO} lastFetch={lastFetch} buoyFetchedAt={data?.buoyFetchedAt} />

      {/* Buoy data notice */}
      {data?.buoyError && (
        <div style={{ background:'rgba(212,130,74,0.1)', border:'1px solid rgba(212,130,74,0.3)', borderRadius:'10px', padding:'12px 18px', margin:'16px 0', fontFamily:'var(--font-body)', fontSize:'13px', color:'var(--sunset)', display:'flex', justifyContent:'space-between', alignItems:'center', position:'relative', zIndex:1 }}>
          <span>⚠️ Buoy data pending — GitHub Actions fetches NOAA data hourly. Weather data is live.</span>
          <button onClick={refetch} style={{ background:'transparent', border:'1px solid var(--sunset)', borderRadius:'6px', color:'var(--sunset)', fontFamily:'var(--font-mono)', fontSize:'11px', padding:'6px 14px', cursor:'pointer', marginLeft:'12px', textTransform:'uppercase', letterSpacing:'0.06em' }}>Retry</button>
        </div>
      )}

      {error && (
        <div style={{ background:'rgba(196,97,74,0.1)', border:'1px solid rgba(196,97,74,0.3)', borderRadius:'10px', padding:'12px 18px', margin:'16px 0', fontFamily:'var(--font-body)', fontSize:'13px', color:'var(--coral)', display:'flex', justifyContent:'space-between', alignItems:'center', position:'relative', zIndex:1 }}>
          <span>⚠️ {error}</span>
          <button onClick={refetch} style={{ background:'transparent', border:'1px solid var(--coral)', borderRadius:'6px', color:'var(--coral)', fontFamily:'var(--font-mono)', fontSize:'11px', padding:'6px 14px', cursor:'pointer', marginLeft:'12px', textTransform:'uppercase', letterSpacing:'0.06em' }}>Retry</button>
        </div>
      )}

      {loading && !data && (
        <div style={{ textAlign:'center', padding:'48px 0', fontFamily:'var(--font-mono)', fontSize:'13px', color:'var(--text-muted)', position:'relative', zIndex:1 }}>
          <style>{`@keyframes bob{0%,100%{transform:translateY(0)}50%{transform:translateY(-4px)}}`}</style>
          <span style={{ display:'inline-block', animation:'bob 1.4s ease-in-out infinite', marginRight:'10px', fontSize:'20px' }}>🌊</span>
          Loading conditions...
        </div>
      )}

      {/* Hero scores */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'18px', margin:'24px 0 18px', position:'relative', zIndex:1 }}>
        <SurfCard  score={surfScore}  quality={surfQual} data={data} advice={surfTip} />
        <VolleyCard score={volScore}  condition={volCond} data={data} advice={volTip} />
      </div>

      <ConditionsStrip data={data} />

      {/* Map */}
      <SectionTitle>Spot Locator</SectionTitle>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 290px', gap:'18px', marginBottom:'28px', position:'relative', zIndex:1 }}>
        <SpotMap activeSpot={activeSpot} onSpotClick={setActiveSpot} />
        <div style={{ display:'flex', flexDirection:'column', gap:'8px', overflowY:'auto', maxHeight:'460px' }}>
          {SPOTS.map(spot => (
            <div key={spot.id} onClick={() => setActiveSpot(spot.id === activeSpot ? null : spot.id)}
              style={{ background: spot.id === activeSpot ? 'var(--sand-deeper)' : 'var(--sand-dark)', border:`1px solid ${spot.id === activeSpot ? spot.color : 'var(--border-soft)'}`, borderRadius:'10px', padding:'12px 14px', cursor:'pointer', transition:'all 0.2s' }}>
              <div style={{ fontFamily:'var(--font-display)', fontSize:'14px', fontWeight:600, color:'var(--text)' }}>{spot.name}</div>
              <div style={{ fontFamily:'var(--font-mono)', fontSize:'10px', color:'var(--text-muted)', margin:'2px 0 6px' }}>{spot.sub}</div>
              <span style={{ display:'inline-block', fontFamily:'var(--font-mono)', fontSize:'10px', padding:'2px 8px', borderRadius:'10px', background:`${spot.color}15`, color:spot.color, letterSpacing:'0.04em' }}>{spot.tag}</span>
            </div>
          ))}
        </div>
      </div>

      <MeetupBoard />

      <div style={{ borderTop:'1px solid var(--border)', paddingTop:'20px', display:'flex', justifyContent:'space-between', fontFamily:'var(--font-mono)', fontSize:'10px', color:'var(--text-muted)', letterSpacing:'0.05em' }}>
        <span>SOUTH BAY HUB · 33.88°N 118.41°W · Manhattan Beach</span>
        <span>NOAA 46025 + 46221 (hourly) · Open-Meteo (live) · Auto-refresh 30min</span>
      </div>
    </div>
  )
}
