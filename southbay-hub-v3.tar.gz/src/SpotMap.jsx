import { useEffect, useRef } from 'react'
import L from 'leaflet'

export const SPOTS = [
  { id: 'marine',      name: 'Marine St Courts',        sub: 'Manhattan Beach',        tag: 'Pro Focus',       lat: 33.8853, lon: -118.4104, color: '#2a6b8a', popup: '<b style="color:#2a6b8a">Marine St Courts</b><br>Pro-level · 6 courts · Lights<br><i style="color:#4a5e3a">Best: A / Open pickup</i>' },
  { id: 'mb-pier',     name: 'MB Pier Courts',           sub: 'Manhattan Beach',        tag: 'Iconic',          lat: 33.8842, lon: -118.4097, color: '#2a6b8a', popup: '<b style="color:#2a6b8a">Manhattan Beach Pier Courts</b><br>Most famous courts in the world<br><i style="color:#4a5e3a">AVP history · All levels</i>' },
  { id: '22nd',        name: '22nd St Courts',           sub: 'Manhattan Beach',        tag: 'High Level',      lat: 33.8817, lon: -118.4117, color: '#2a6b8a', popup: '<b style="color:#2a6b8a">22nd St Courts</b><br>High-intermediate · 4 courts<br><i style="color:#4a5e3a">Best: BB / A competitive</i>' },
  { id: '26th',        name: '26th St Courts',           sub: 'Manhattan Beach',        tag: 'Competitive',     lat: 33.8858, lon: -118.4110, color: '#2a6b8a', popup: '<b style="color:#2a6b8a">26th St Courts</b><br>Strong competitive scene<br><i style="color:#4a5e3a">Best: A / competitive</i>' },
  { id: 'hermosa-pier',name: 'Hermosa Pier Courts',      sub: 'Hermosa Beach',          tag: 'Social',          lat: 33.8622, lon: -118.4000, color: '#d4824a', popup: '<b style="color:#d4824a">Hermosa Pier Courts</b><br>Challenge court culture · All day<br><i style="color:#d4824a">Best social scene on the Strand</i>' },
  { id: 'hermosa-12th',name: '12th St Courts',           sub: 'Hermosa Beach',          tag: 'Intermediate',    lat: 33.8602, lon: -118.3998, color: '#d4824a', popup: '<b style="color:#d4824a">12th St Courts</b><br>Great intermediate scene<br><i style="color:#d4824a">Best: BB level</i>' },
  { id: 'hermosa-6th', name: '6th St Courts',            sub: 'Hermosa Beach',          tag: 'Mixed',           lat: 33.8568, lon: -118.3995, color: '#d4824a', popup: '<b style="color:#d4824a">6th St Courts</b><br>Mixed levels · Good scene<br><i style="color:#d4824a">Best: B / BB</i>' },
  { id: 'hermosa-1st', name: '1st St Courts',            sub: 'Hermosa Beach',          tag: 'South End',       lat: 33.8539, lon: -118.3990, color: '#d4824a', popup: '<b style="color:#d4824a">1st St Courts</b><br>Quieter · Great for practice<br><i style="color:#d4824a">All levels welcome</i>' },
  { id: 'redondo',     name: 'Redondo Esplanade Courts', sub: 'Redondo Beach',          tag: 'Wind Protected',  lat: 33.8455, lon: -118.3932, color: '#4a5e3a', popup: '<b style="color:#4a5e3a">Redondo Esplanade Courts</b><br>Wind-protected by breakwater<br><i style="color:#4a5e3a">Best on heavy wind days</i>' },
  { id: 'torrance',    name: 'Torrance Beach Courts',    sub: 'Redondo / Torrance',     tag: 'Chill Vibes',     lat: 33.8380, lon: -118.3900, color: '#4a5e3a', popup: '<b style="color:#4a5e3a">Torrance Beach Courts</b><br>Laid-back · Less crowded<br><i style="color:#4a5e3a">Beginners welcome</i>' },
  { id: 'dockweiler',  name: 'Dockweiler Courts',        sub: 'Playa del Rey',          tag: 'Night Play',      lat: 33.9297, lon: -118.4272, color: '#8b7355', popup: '<b style="color:#8b7355">Dockweiler Courts</b><br>Lit courts · Fire pits<br><i style="color:#8b7355">Great evening sessions</i>' },
]

const icon = (color, active) => L.divIcon({
  html: `<div style="width:${active?13:9}px;height:${active?13:9}px;border-radius:50%;background:${color};border:2px solid ${color}60;box-shadow:0 0 ${active?10:4}px ${color}80;"></div>`,
  className: '', iconSize: [active?13:9, active?13:9], iconAnchor: [active?6:4, active?6:4],
})

export default function SpotMap({ activeSpot, onSpotClick }) {
  const mapRef  = useRef(null)
  const mapObj  = useRef(null)
  const markers = useRef({})

  useEffect(() => {
    if (mapObj.current) return
    const map = L.map(mapRef.current, { center: [33.876, -118.403], zoom: 13, zoomControl: false })
    L.control.zoom({ position: 'bottomright' }).addTo(map)

    // Warm earthy map tiles
    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; <a href="https://carto.com/">CARTO</a>',
      subdomains: 'abcd', maxZoom: 19,
    }).addTo(map)

    // Buoy markers
    ;[
      { lat: 33.749, lon: -119.053, id: '46025', desc: 'Outer Scout · Period + Direction', color: '#2a6b8a' },
      { lat: 33.855, lon: -118.633, id: '46221', desc: 'Inner Confirm · Wave Height',      color: '#4a5e3a' },
    ].forEach(b => {
      L.marker([b.lat, b.lon], {
        icon: L.divIcon({ html: `<div style="width:8px;height:8px;border-radius:50%;background:${b.color};border:2px solid white;box-shadow:0 0 5px ${b.color};"></div>`, className:'', iconSize:[8,8], iconAnchor:[4,4] })
      }).addTo(map).bindPopup(`<b style="color:${b.color}">Buoy ${b.id}</b><br><span style="color:var(--text-muted);font-size:11px">${b.desc}</span>`)
    })

    SPOTS.forEach(spot => {
      const m = L.marker([spot.lat, spot.lon], { icon: icon(spot.color, false) })
        .addTo(map)
        .bindPopup(`<div style="font-family:'DM Mono',monospace;font-size:12px;line-height:1.6">${spot.popup}</div>`, { maxWidth: 220 })
      m.on('click', () => onSpotClick(spot.id))
      markers.current[spot.id] = { m, color: spot.color }
    })
    mapObj.current = map
  }, [])

  useEffect(() => {
    SPOTS.forEach(spot => {
      const entry = markers.current[spot.id]
      if (!entry) return
      const active = spot.id === activeSpot
      entry.m.setIcon(icon(spot.color, active))
      if (active) { mapObj.current?.flyTo([spot.lat, spot.lon], 15, { duration: 1.2 }); entry.m.openPopup() }
    })
  }, [activeSpot])

  return <div ref={mapRef} style={{ height: '460px', borderRadius: '12px', border: '1px solid var(--border)', overflow: 'hidden' }} />
}
