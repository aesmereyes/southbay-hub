import { useState, useEffect, useCallback, useRef } from 'react'

const BASE = import.meta.env.BASE_URL  // '/southbay-hub/' in prod, '/' in dev

const WEATHER_URL =
  'https://api.open-meteo.com/v1/forecast' +
  '?latitude=33.88&longitude=-118.41' +
  '&current=temperature_2m,wind_speed_10m,wind_direction_10m,cloud_cover,uv_index' +
  '&daily=sunrise,sunset' +
  '&timezone=America%2FLos_Angeles' +
  '&forecast_days=2'

export function useStationData() {
  const [data, setData]       = useState(null)
  const [error, setError]     = useState(null)
  const [loading, setLoading] = useState(true)
  const [lastFetch, setLastFetch] = useState(null)
  const timerRef = useRef(null)

  const fetchAll = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      // buoy-data.json is committed to the repo by GitHub Actions every hour
      // No CORS issues — it's served from the same origin as the app
      const buoyUrl = `${BASE}buoy-data.json?t=${Date.now()}`

      const [buoyRes, weatherRes] = await Promise.all([
        fetch(buoyUrl),
        fetch(WEATHER_URL),
      ])

      const buoy    = await buoyRes.json()
      const weather = await weatherRes.json()

      const b25 = buoy.buoy_46025  // outer: period + direction
      const b21 = buoy.buoy_46221  // inner: wave height

      const w = weather.current
      const windMph = +(w.wind_speed_10m * 0.6214).toFixed(1)
      const tempF   = +((w.temperature_2m * 9 / 5) + 32).toFixed(1)

      setData({
        // Wave data — dual-buoy merge strategy
        wvhtFt:    b21?.wvht_ft  ?? b25?.wvht_ft  ?? null,  // height from inner
        wvhtFt25:  b25?.wvht_ft  ?? null,                    // outer raw
        wvhtFt21:  b21?.wvht_ft  ?? null,                    // inner confirm
        dpdS:      b25?.dpd_s    ?? b21?.dpd_s    ?? null,   // period from outer
        mwdDeg:    b25?.mwd_deg  ?? b21?.mwd_deg  ?? null,   // direction from outer
        waterTempF: b21?.wtmp_f  ?? b25?.wtmp_f   ?? null,
        b25Time:   b25?.timestamp ?? null,
        b21Time:   b21?.timestamp ?? null,
        buoyFetchedAt: buoy.fetched_at,
        buoyError:     buoy.error ?? null,

        // Weather from Open-Meteo
        windMph,
        windDirDeg:  w.wind_direction_10m,
        cloudPct:    w.cloud_cover,
        uvIndex:     w.uv_index,
        tempF,
        sunriseISO:  weather.daily.sunrise[0],
        sunsetISO:   weather.daily.sunset[0],
      })
      setLastFetch(new Date())
    } catch (e) {
      console.error('Data fetch error:', e)
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchAll()
    timerRef.current = setInterval(fetchAll, 30 * 60 * 1000)
    return () => clearInterval(timerRef.current)
  }, [fetchAll])

  return { data, error, loading, lastFetch, refetch: fetchAll }
}
